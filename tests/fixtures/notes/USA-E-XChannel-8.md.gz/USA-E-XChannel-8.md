![](img/USA-E-XChannel.jpg)

<span id="page268"></span>

> ## Chapter VIII: The Sixth of June
>
> <span id="map1"></span>
>
> <a href="maps/USA-E-XChannel-1.jpg" target="mapwindow"><img src="maps/USA-E-XChannel-1m.jpg" /></a>  
> *Map 1*
>
> ### *The Invasion Is Launched*
>
> On 8 May General Eisenhower set D Day for Y plus 4, or 5 June. The plans were made (though changes would be introduced up to the last minute), the troops were trained, the preparatory softening up of the enemy was well under way. What remained was to get the men on ships and give the order to go. The vastly complicated process of organizing and equipping the assault units for embarkation began in April. It followed in general the pattern worked out in British exercises in the fall of 1943 which broke down the mounting into a series of movements bringing the troops successively nearer embarkation and at the same time providing for their equipment and assault organization. Unless the troops were already stationed near the south coast of England, they were moved first to concentration areas where they received special equipment, waterproofed their vehicles, and lost certain administrative overhead considered unessential during the assault. The second move brought them to marshaling areas located close to the embarkation points. There, final supplies were issued for the voyage, maps distributed, briefing for the operation accomplished, and the units broken down into boatloads to await the final move down to the ships.<sup><a href="#fn1" id="cn1">1</a></sup>
>
> Force U (seaborne units of the VII Corps) was marshaled in the Tor Bay area and east of Plymouth; Force O (1st Division), in the area of Dorchester; Force B (29th Division), near Plymouth and Falmouth; and the early build-up divisions, the 9th Infantry and 2d Armored Divisions, near Southampton. Marshaling areas for the airborne units were as follows: glider troops in the central counties between London and the Severn River; paratroopers of the 101st Division in the Newbury-Exeter area; paratroopers of the 82d Division in the eastern half of England, north of London.<sup><a href="#fn2" id="cn2">2</a></sup> (<a href="maps/USA-E-XChannel-VII.jpg" target="mapwindow"><em>Map VII</em></a>)
>
> About 54,000 men, including the temporary housekeeping services of the entire 5th Armored Division, were required to establish and maintain installations for mounting the seaborne assault forces alone, and to perform services necessary to make them ready for sailing. To cook their meals, more than 4,500 new army cooks were trained during the first three months of 1944. To transport them and haul their supplies, over 3,800 trucks were operated by the Southern Base Section.
>
> Through the first five months of 1944 individual and group assault training had continued, supplemented from January on by large-scale exercises designed to test not only assault techniques but coordination between the joint armies, smoothness of staff work in all phases of the operation, and techniques of mounting, marshaling,

*--269--*

------------------------------------------------------------------------

<span id="page270"></span>

> loading, and unloading. These exercises culminated in two dress rehearsals for the invasion: exercise TIGER for Force U (VII Corps units) held at the end of April; the series of exercises, FABIUS, for Force O (1st Division), Force B (29th Division), and British assault and follow-up forces conducted in the early part of May.
>
> The assault exercises were held at Slapton Sands on the coast of Devon southwest of Dartmouth under conditions simulating as closely as possible those expected in the actual operations. As a result of the exercises certain minor technical improvements were made, but the basic organization and the techniques as worked out at the Assault Training Center were unchanged.
>
> Amid all the simulation there came one serious note of war. One of the convoys of exercise TIGER was attacked by two German E-boat flotillas totaling nine boats.<sup><a href="#fn3" id="cn3">3</a></sup> Losses were heavier than those suffered by Force U during the actual invasion. Two LST's were sunk and one damaged. About 700 men lost their lives.<sup><a href="#fn4" id="cn4">4</a></sup> The loss of three LST's to the OVERLORD assault lift was particularly critical in view of the general shortage of landing craft. General Eisenhower reported to the Combined Chiefs of Staff that the sinkings reduced the reserve of LST's to nothing.<sup><a href="#fn5" id="cn5">5</a></sup> The Germans realized that they had sunk landing craft but guessed that the craft had been participating in an exercise.<sup><a href="#fn6" id="cn6">6</a></sup> The incident passed without repercussions.
>
> After the TIGER and FABIUS rehearsals the assault troops returned to the marshaling areas to complete their last minute preparations and to wait. Troops of Force U had almost a month of waiting. It was a trying time for the men and a dangerous time for the fate of the invasion. Although troops were not briefed on operation OVERLORD until the last week in May, the fact that they were concentrated and ready to go and that they had just practiced the invasion maneuver with the organization actually to be used would have been sufficient information in the hands of enemy agents to jeopardize the operation. All troops were therefore sealed in the marshaling areas behind barbed wire and with a host of some 2,000 Counter Intelligence Corps men guarding them closely. The whole coastal area had been closed to visitors since April. Now, in addition, the camps themselves were isolated from all contact with the surrounding countryside. Camouflage discipline was more severely enforced during these weeks than at any time subsequently during actual operations. The German Air Force, though weak, was believed capable of damaging raids against troop concentrations and port areas. Actually, only one raid of any consequence did occur, when on the night of 30 May bombs were dropped in

*--270--*

------------------------------------------------------------------------

<span id="page271"></span>

> <a href="img/USA-E-XChannel-35.jpg" target="mapwindow"><img src="icn/USA-E-XChannel-35.jpg" /></a>
>
> PREINVASION SCENES. *Soldiers in mess line (above) in one of the marshaling camps in southern England, and (below) men and equipment being loaded on LST's at Brisham.*
>
> <a href="img/USA-E-XChannel-36.jpg" target="mapwindow"><img src="icn/USA-E-XChannel-36.jpg" /></a>

*--271--*

------------------------------------------------------------------------

<span id="page272"></span>

> a camp near Falmouth, causing a few casualties to an ordnance battalion. The enemy continued to miss his opportunities to disrupt the final preparations.
>
> Loading of Force U, Force O, and Force B began on 30 May, 31 May, and 1 June, respectively, and all troops were aboard by 3 June. Force U craft were loaded mostly at Plymouth, Dartmouth, Tor Bay, Torquay, Poole, Salcombe, Brixham, and Yarmouth. They were divided into twelve convoys for the cross-Channel movement depending on their missions, assembly points, and speed. Force O was split into five convoys and the craft loaded in a relatively concentrated area including the ports of Portland, Weymouth, and Poole.<sup><a href="#fn7" id="cn7">7</a></sup>
>
> Operation OVERLORD was ready.
>
> On 29 May the senior meteorologist for SHAEF, Group Captain J. M. Stagg of the RAF, had drawn an optimistic long-range forecast of the weather to be expected in the first week of June. On the basis of that forecast all preparations had been made. General Eisenhower cabled General Marshall on Saturday, 3 June: "We have almost an even chance of having pretty fair conditions . . . only marked deterioration . . . would discourage our plans."<sup><a href="#fn8" id="cn8">8</a></sup> But marked deterioration was already in the cards. That Saturday evening Group Captain Stagg again came before the Supreme Commander and his commanders in chief who were meeting at Southwick House north of Portsmouth, the headquarters of Admiral Ramsay. Group Captain Stagg had bad news. Not only would the weather on 5 June be overcast and stormy with high winds and a cloud base of 500 feet to zero, but the weather was of such a nature that forecasting more than twenty-four hours in advance was highly undependable. The long period of settled conditions was breaking up. It was decided, after discussion, to postpone decision for seven hours and in the meantime let Force U and part of Force O sail on schedule for their rendezvous for the June D Day.
>
> At 0430 Sunday morning a second meeting was held at which it was predicted that the sea conditions would be slightly better than anticipated but that overcast would still not permit use of the air force. Although General Montgomery then expressed his willingness to go ahead with the operation as scheduled, General Eisenhower decided to postpone it for twenty-four hours. He felt that OVERLORD was going in with a very slim margin of ground superiority and that only the Allied supremacy in the air made it a sound operation of war. If the air could not operate, the landings should not be risked. A prearranged signal was sent out to the invasion fleet, many of whose convoys were already at sea.<sup><a href="#fn9" id="cn9">9</a></sup> The ships turned back and prepared to rendezvous twenty-four hours later.
>
> On Sunday night, 4 June, at 2130 the high command met again in the library of Southwick House. Group Captain Stag reported a marked change in the weather. A rain front over the assault area was expected to clear in two or three hours and the clearing would last until Tuesday morning. Winds then of 25 to

*--272--*

------------------------------------------------------------------------

<span id="page273"></span>

> <a href="img/USA-E-XChannel-37.jpg" target="mapwindow"><img src="icn/USA-E-XChannel-37.jpg" /></a>  
> ALLIED INVASION CHIEFS. Left to right: General Bradley, Admiral Ramsey, Air Chief Marshal Tedder, General Eisenhower, General Montgomery, Air Chief Marshal Leigh-Mallory, General Smith. This photograph was taken during a conference in early 1944.
>
> 31 knots velocity would moderate. Cloud conditions would permit heavy bombing during Monday night and Tuesday morning although there would be considerable cloudiness Tuesday. The cloud base at H Hour might be just high enough to permit spotting for naval gunfire. All this was good news, but it indicated weather that might be barely tolerable rather than ideal for the assault. After listening to the forecast Admiral Ramsay reminded the commanders that there was only half an hour to make a decision, and that if Admiral Kirk's forces were ordered to sail for a D Day on Tuesday, 6 June, and were later recalled they would not be able to sail again for a Wednesday rendezvous, the last day for two weeks on which light and tidal conditions would be suitable for the assault.
>
> Both Eisenhower and General Smith welcomed the break and felt the decision should be made to go in on Tuesday. The gamble that worried Smith was the possibility of not being able to spot naval fire but he thought it was still the best gamble to take. To call off the invasion now meant to wait until 19 June before it could be tried again. Troops would have to be disembarked with great risk to security, as well as to morale. The 19 June date would mean acceptance of moonless conditions for the airborne drops. Finally, the longer the postponement, the shorter the period of good campaigning weather on the Continent.
>
> Still Air Chief Marshal Leigh-Mallory was skeptical of the ability of the air force to operate effectively in the overcast predicted. Air Chief Marshal Tedder agreed that the operations of heavies and mediums were going to be "chancey."

*--273--*

------------------------------------------------------------------------

<span id="page274"></span>

> General Eisenhower refused the pessimistic view. "We have a great force of fighter-bombers," he said, and then turning to General Montgomery he asked, "Do you see any reason for not going Tuesday"?
>
> "I would say--Go!" Montgomery replied.
>
> "The question," Eisenhower pointed out, "\[is\] just how long can you hang this operation on the end of a limb and let it hang there."
>
> The discussion continued a few more minutes.
>
> At 2145 Eisenhower announced his decision. "I'm quite positive we must give the order...I don't like it, but there it is...I don't see how we can possibly do anything else."<sup><a href="#fn10" id="cn10">10</a></sup>
>
> There remained still a possibility that the weather might become so much worse that the decision would have to be reversed. A final meeting was held shortly after midnight. Weather charts were studied again, but nothing had changed. The invasion was launched and through the choppy waters of the Channel the 5,000 ships and craft of the largest fleet ever assembled held to their carefully plotted courses toward the transport areas off the enemy coast.
>
> When General Eisenhower left Southwick House before dawn of 5 June, he had made the last of a long series of planning and command decisions which through three and a half years had translated the idea of the cross-Channel attack into an operation of war. The war leaders, the high commanders, the planners with whom we have been so long concerned had no choice now but to sit back and wait. They had done what they could to insure that the men who crossed the Channel on 5 June 1944 should have the greatest possible chance of success at a cost as low as careful planning could set it. Long before the armada sailed, the Combined Chiefs of Staff had focused their attention far ahead of the battle of the beaches. The SHAEF staff similarly had long been working on plans for the later phases of the operation. The nearer H Hour approached, the more heavily and exclusively the responsibility for the invasion settled on the lower commanders.
>
> In the narrative to follow, the great names drop out. Even Eisenhower and Montgomery appear but seldom. In their place will be the corps and division commanders, the colonels, the lieutenants, and the privates. For the few will be substituted the many, as the battlefield, so long seen as a single conceptual problem, becomes a confused and disparate fact-a maze of unrelated orchards and strange roads, hedgerows, villages, streams and woods, each temporarily bounding for the soldier the whole horizon of the war.
>
> One may say of almost any successful operation that it carried out the plan, but this is to say little of how or why it succeeded. The Normandy assault was perhaps as thoroughly planned as any battle in the history of war. Nevertheless the fighting men went in trained to improvise battlefield solutions to the immediate problems facing them-how to take out an unseen machine gun in the hedgerows, how to outflank an enemy holed

*--274--*

------------------------------------------------------------------------

<span id="page275"></span>

> up in a stone farmhouse. The fighting in these terms proceeded not according to plan but according to the trial and error of battle. It is to the narrative of this testing that we now turn.
>
> While the Allied invasion force steamed across the Channel, the Germans in France, so long schooled for this moment, had no direct knowledge that it was at hand. The enemy was all but blind. There had been no air reconnaissance during the first five days of June. Naval patrols scheduled for the night of 5-6 June, along with the minelaying operations for that date, were canceled because of bad weather.
>
> The stages of alert among the various commands in the west varied, reflecting both the nebulous character of such intelligence as was available and the lack of command unity. On 1 and 2 June German agents who had penetrated Resistance groups picked up twenty-eight of the 13 BC prearranged signals ordering the Resistance to stand by for the code messages that would direct the execution of sabotage plans. The central SS intelligence agency in Berlin reported these intercepts on 3 June to Admiral Doenitz and warned that invasion could be considered possible within the next fortnight. At the admiral's headquarters they were not taken too seriously. It was thought that perhaps an exercise was in progress.<sup><a href="#fn11" id="cn11">11</a></sup>
>
> On the evening of 5 June *OB WEST* and *Fifteenth Army* independently intercepted the "B" messages which at this time *Fifteenth Army* at least understood to be warnings of invasion within forty-eight hours.<sup><a href="#fn12" id="cn12">12</a></sup> This was at 2215,<sup><a href="#fn13" id="cn13">13</a></sup> precisely the hour at which the transport planes carrying troops of the U.S. 101st Airborne Division began taking off from airfields in England. What happened next is not altogether clear. While *Fifteenth Army* put its troops on the highest alert, *Army Group B* apparently took no action. On the basis of past experience Rommel's staff considered it unlikely that the intercepts warned of an imminent invasion. Rommel himself was in Herrlingen at his home, on his way to visit Hitler at Obersalzburg; he was not immediately called back. *Army Group B* did not alert *Seventh Army.* In fact the routine daily orders from *Seventh Army* headquarters to subordinate corps on the evening of 5 June actually canceled a planned alert for that night.<sup><a href="#fn14" id="cn14">14</a></sup> Perhaps the chief reason for the cancellation was that a map exercise, to which a number of division and lower commanders in *Seventh Army* had been invited, was scheduled for the morning of 6 June at Rennes. Whatever the reason, it is apparent that General Dollmann believed on the night of 5 June that there was less cause for alarm than on many a previous night in May when his troops had been alerted.
>
> The net effect on German preparedness of the intercepted warnings to the Resistance was therefore slight. *Seventh Army* was alerted only in the sense that it was in the same state of "defensive

*--27--*

------------------------------------------------------------------------

<span id="page276"></span>

> readiness" that it had been in all through the spring. The Resistance messages of the evening of 5 June may have persuaded *OB WEST* that invasion was imminent, although there is evidence that Rundstedt's intelligence officer at least rejected the warning on grounds that it would be absurd for the Allies to announce their invasion in advance over the BBC.<sup><a href="#fn15" id="cn15">15</a></sup> In any case, a last-minute alert of the supreme headquarters in such vague terms was of little value for the command. It gave no indication of where or precisely when the Allies would strike; reconnaissance, moreover, could not be put out in time to answer these questions.
>
> As for the Navy, it was, on 5 June, thoroughly complacent. German naval experts had calculated that Allied landings would be possible only in seas of less than intensity 4,<sup><a href="#fn16" id="cn16">16</a></sup> with a wind force up to 24 knots and a visibility of at least three sea miles. These conditions were not being met on 5 June.<sup><a href="#fn17" id="cn17">17</a></sup> Lacking weather-reporting stations to the west whence most of the Channel weather came, the German meteorologists were unable to make reliable predictions.<sup><a href="#fn18" id="cn18">18</a></sup> Weather planes flew out over the North Sea daily to points west of Ireland, but the data provided by their observations were of limited usefulness. The Germans could not have forecast the break in the weather which Group Captain Stagg reported to General Eisenhower.<sup><a href="#fn19" id="cn19">19</a></sup> Although there is no evidence that meteorologists advised German commanders that invasion on 6 June was impossible, it is clear that the generally unfavorable wind and sea conditions contributed to reducing the enemy's alertness.<sup><a href="#fn20" id="cn20">20</a></sup>
>
> This was particularly true of the naval command. Lulled into a sense of security by the weather and the judgment that the Allies had not yet completed essential preparatory bombardment of the coastal fortifications, Admiral Krancke received reports of the SOE intercepts on 5 June without alarm. Notice of the BBC affair was faithfully transcribed in his war diary for 6 June together with his assurances that nothing was likely to happen-all under the general heading: "Large-scale enemy landing in the Seine Bay.<sup><a href="#fn21" id="cn21">21</a></sup>

*--276--*

------------------------------------------------------------------------

<span id="page277"></span>

> <a href="img/USA-E-XChannel-38.jpg" target="mapwindow"><img src="icn/USA-E-XChannel-38.jpg" /></a>   <a href="img/USA-E-XChannel-39.jpg" target="mapwindow"><img src="icn/USA-E-XChannel-39.jpg" /></a>
>
> GERMAN FIELD COMMANDERS. *Upper left, General von Schlieben; upper General Marcks; lower left, General Geyr von Schweppenburg; lower right, General Dollmann.*
>
> <a href="img/USA-E-XChannel-40.jpg" target="mapwindow"><img src="icn/USA-E-XChannel-40.jpg" /></a>   <a href="img/USA-E-XChannel-41.jpg" target="mapwindow"><img src="icn/USA-E-XChannel-41.jpg" /></a>

*--277--*

------------------------------------------------------------------------

<span id="page278"></span>

> ### *The Airborne Assault*
>
> The time and place at least of the "large-scale landing" caught the Germans wholly by surprise. *Seventh Army's* first knowledge that anything was afoot was a series of reports in the early morning hours of 6 June that Allied paratroopers were dropping from the skies over Normandy. At 0130 Lt. Col. Hoffmann, commander of the *3d Battalion,* *919th Regiment* of the *709th Division*) was at his headquarters in St. Floxel east of Montebourg. (<a href="maps/USA-E-XChannel-VIII.jpg" target="mapwindow"><em>Map VIII</em></a>) He heard aircraft approaching. The sound indicated great numbers, and, as he listened during the next hour, it seemed to him to swell louder and louder. At 0200 six airplanes flying, he thought, at about 500 feet approached the headquarters shelter and released parachutists in front of and above it. In a few minutes Hoffmann's staff and security guards were heavily engaged with paratroopers of the 101st Airborne Division in one of the opening skirmishes of the battle for Normandy.<sup><a href="#fn22" id="cn22">22</a></sup>
>
> News of the landings spread fast. At 0215 *Seventh Army* ordered the highest state of alarm through the *LXXXIV Corps* sector. The alarm was passed at once by wire to all Army, Navy and Air Force units in the corps area. At 0220 *Naval Commander Normandy* (Konteradmiral Walther Hennecke)<sup><a href="#fn23" id="cn23">23</a></sup> reported paratroopers near the Marcouf battery. During the next five minutes additional reports came in of landings in the sector of the *716th* and *711th Divisions.* Before three o'clock *LXXXIV Corps* had taken its first prisoner. The situation was still obscure, but, as reports piled in, something of the extent and scale of the operation became visible. Generalmajor Max Pemsel, *Seventh Army* chief of staff, had already (by 0300) concluded that the long-heralded major invasion had begun, and had correctly located the points of main effort near Carentan and Caen.<sup><a href="#fn24" id="cn24">24</a></sup> His judgment, however, was at this time a minority report. Field Marshals Rundstedt and Sperrle and Admiral Krancke as well as Rommel's chief of staff, Generalleutnant Hans Spieled, all thought they were probably experiencing the diversionary operation which had been expected in the *Seventh Army* area while the Allies prepared to strike the main blow against *Fifteenth Army.* But, whatever the larger estimate of the situation, local measures could be and were promptly taken. The *91st Division* in reserve in the Cotentin was released to *Seventh Army,* attached to *LXXXIV Corps,* and, together with the *709th Division,* was ordered to counterattack. There was actually little else to be done. All units in the Cotentin had been briefed to expect airborne operations. The meeting engagement was inevitably the individual problem of these units.
>
> The situation on the American side was similar. The first actions of all airborne units in the Cotentin on D Day were attempts by small groups of men to carry out in the fog of the battlefield their own small portions of the assigned plan. There could be little over-all direction from above. And, in fact, little information

*--278--*

------------------------------------------------------------------------

<span id="page279"></span>

> <a href="img/USA-E-XChannel-42.jpg" target="mapwindow"><img src="icn/USA-E-XChannel-42.jpg" /></a>  
> PARACHUTE TROOPS *marching onto airfield on evening of 5 June.*
>
> got through to corps and army as to what was happening.<sup><a href="#fn25" id="cn25">25</a></sup>
>
> By the revised VII Corps field order of 28 May both U.S. airborne divisions were to land in the eastern half of the peninsula between Ste. Mère-Eglise and Carentan, establishing a beachhead from which the corps would push west and north to the capture of Cherbourg. The six parachute regiments of the two divisions, which together with organic supporting units numbered over 13,000 men, were loaded in 822 transport planes at nine airfields in England. They began taking off before midnight to fly routes calculated to bring the first serials in from the west side of the Cotentin Peninsula and over the designated drop zones between 0115 and 0130. The main flights were preceded by pathfinder planes that were to land paratroopers to mark the drop zones. Glider reinforcements would be brought in at dawn and again at dusk on landing zones that the paratroopers were expected to have cleared of the enemy. The whole airborne operation was by far the largest and most hazardous ever undertaken, and thousands of American lives depended on its success.<sup><a href="#fn26" id="cn26">26</a></sup>

*--279--*

------------------------------------------------------------------------

<span id="page280"></span>

> The primary mission of the 101st Airborne Division was to seize the western edge of the flooded area back of the beach between St. Martin-de-Varreville and Pouppeville. Its secondary mission was to protect the southern flank of VII Corps and be prepared to exploit southward through Carentan. The latter task was to be carried out by destroying two bridges on the main Carentan highway and the railroad bridge west of it, by seizing and holding the la Barquette lock, and finally by establishing a bridgehead over the Douve River northeast of Carentan.
>
> Two parachute regiments less one battalion, the 502d and the 506th(-), were assigned the primary mission. The 502d Parachute Infantry, with the 377th Parachute Field Artillery Battalion attached, was to drop near St. Martin-de-Varreville, destroy the enemy coastal battery there, secure the two northern beach exits, and establish a defensive line tying in the division's north flank with the 82d Airborne Division to the west. The 506th Infantry would seize the two southern exits.
>
> The four battalion serials of the 502d Infantry came in ten minutes apart led by the 2d Battalion and regimental headquarters. The leading planes, scattered by clouds and flak, dropped the majority of the 2d Battalion outside their assigned zone. (<a href="maps/USA-E-XChannel-IX.jpg" target="mapwindow"><em>Map IX</em></a>) The battalion as a result spent most of the day assembling and, as a unit, took no part in the D-Day fighting. The regiment's planned artillery support did not materialize. Only one of the six howitzers of the 377th Field Artillery Battalion was recovered after the drop, and the fifty men of the battalion who assembled during the day fought as infantry in scattered actions.<sup><a href="#fn27" id="cn27">27</a></sup>
>
> The commander of the 3d Battalion, 502d, Lt. Col. Robert G. Cole, dropped east of Ste. Mère-Eglise. (See <a href="maps/USA-E-XChannel-VIII.jpg" target="mapwindow"><em>Map VIII</em></a>.) He began then to make his way toward St. Martin-de-Varreville. Out of the darkness, toy "crickets" snapped as paratroopers identified themselves and began assembling in groups. The groups were generally miscellaneous at first. The men looked only for company and leadership. Seventy-five men, including some paratroopers from the 82d Airborne Division, gathered in this way under Colonel Cole and moved steadily toward the coast. Except for an encounter with a small enemy convoy on the way, in which some Germans were killed and ten taken prisoner, the group had no trouble reaching its objective. Discovering that the guns of the St. Martin coastal battery had been removed and that the position was deserted, Cole went on to Audouville-la-Hubert where his men established themselves at the western end of the causeway without a fight.<sup><a href="#fn28" id="cn28">28</a></sup> About

*--280--*

------------------------------------------------------------------------

<span id="page281"></span>

> two hours later, at 0930, the enemy began retreating across the causeway from the beach. The paratroopers, lying in wait, shot down fifty to seventy-five and at 1300 made contact with the 8th Infantry (4th Division). They had suffered no casualties. Cole, having completed his mission, remained in the area to collect and organize his battalion. By the end of the day he had about 250 men. With this group he was ordered into regimental reserve near Blosville for the next day's operations.
>
> The 1st Battalion, 502d Parachute Infantry (Lt. Col. Patrick J. Cassidy), had a much harder fight for its objectives. Colonel Cassidy, landing about in the center of the battalion zone near St. Germain-de-Varreville, collected a small force mostly of his own men and moved toward the stone buildings on the eastern edge of Mésières which were thought to be occupied by the German unit manning the St. Martin coastal battery. Without opposition the battalion secured the crossroads west of St. Martin near which the building stood. Taking stock of his position there, Colonel Cassidy found that both the northern exits for which the regiment was responsible were clear. He then made contact with a group of forty-five men of the battalion who had assembled north of his own position and ordered them to establish a defensive line at Foucarville. The situation to the west of St. Martin, however, remained obscure. Colonel Cassidy decided to keep a portion of his force (nominally a company) in reserve to block any enemy attempt to break through from the west to the beaches. A group of about fifteen men was sent to clean out the buildings on the eastern edge of Mésières. This fight was conducted almost single-handedly by S/Sgt. Harrison Summers. Summers rushed the buildings one by one, kicked in the doors, and sprayed the interiors with his Tommy gun. On occasion he had the assistance of another man, but it was his drive and initiative that kept the attack going. When the last building was cleared in the afternoon, about 150 Germans had been killed or captured.<sup><a href="#fn29" id="cn29">29</a></sup>
>
> Near the close of this action Lt. Col. John H. Michaelis, regimental commander, arrived in the area with 200 men. Cassidy was thus free to complete his D-Day mission to cover the north flank of the regiment and tie in with the 82d Airborne Division on the left. While the fight near Mésières was in progress the men of the 1st Battalion whom Colonel Cassidy had sent to Foucarville in the morning had succeeded in establishing four road blocks in and around the town and had trapped and largely destroyed a four-vehicle enemy troop convoy. Despite this early success the road blocks were threatened all day with being overrun by a superior enemy force that occupied prepared positions on a hill to the northwest.
>
> The American situation was not immediately improved by Cassidy's move north, since he came up west of Foucarville in order to carry out the plan of tying in at Beuzeville-au-Plain with the 82d Airborne Division. He ran into trouble there. The company ordered to Beuzeville-au-Plain mistook the hamlet of le Fournel for its objective and there became involved in three separate platoon

*--281--*

------------------------------------------------------------------------

<span id="page282"></span>

> fights which proceeded in some confusion until dark. The troops then withdrew to the south where they remained under enemy pressure during the night. Since contact was not made with the 82d Airborne Division, Cassidy committed the reserve company on the left and moved up some spare riflemen to fill the gap between le Fournel and the road blocks around Foucarville. Even so the whole line remained very weak, and the regimental commander, having already decided to pass the 2d Battalion through the 1st on the following day, ordered Colonel Cassidy to pull back and dig in.
>
> During the night the Germans facing the battalion's right flank at Foucarville unexpectedly decided to surrender, apparently because the increasing volume of American machine gun and mortar fire led them to overestimate the battalion's strength. Eighty-seven Germans were taken prisoner and about fifty more shot down as they attempted to escape.
>
> Here as elsewhere in the 101st Airborne Division's early contacts with the enemy, it seems that the German dispersion of units in small packets to garrison villages and strong points took no account of the splintering effect of airborne landings in their midst, even though the enemy command expected just such landings. The isolated German units, apparently out of contact with their parent outfits, ignorant of what was occurring as well as of what German countermeasures were in the making, were prone to fancy themselves about to be overwhelmed whenever American fire was brought to bear on them with any persistence. The attackers at least had the psychological advantage of knowing the large things that had been planned, even though they seldom knew what was actually happening beyond the field or village in which they found themselves.
>
> The two beach exits south of the zone of the 502d Infantry were the responsibility of the 506th Parachute Infantry Regiment (Col. Robert F. Sink). The 506th (less the 3d Battalion) was to land between Hiesville and Ste. Marie-du-Mont and seize the western edge of the inundated area between Audouville-la-Hubert and Pouppeville. The 3d Battalion, dropping just south of Vierville and charged with defending the Douve River line in the regiment's sector, was to seize two bridges at le Port and establish a bridgehead there for subsequent exploitation southward.
>
> Like the 502d, the 506th experienced a badly scattered drop, but had rather better luck in assembling rapidly. Within two hours of landing, about ninety men of regimental headquarters and fifty men of the 1st Battalion (Lt. Col. William L. Turner) had assembled in the regimental zone. Colonel Sink established his command post at Culoville. At the same time the 2d Battalion (Lt. Col. Robert L. Strayer), despite a landing completely out of its zone in the sector of the 502d Parachute Infantry to the north, succeeded in assembling rapidly about 200 of its men. Strayer had the principal regimental mission of securing the southern beach exits at Houdienville and Pouppeville. Before dawn his men headed south toward their objectives. They ran into opposition on the same road over which the 1st Battalion, 502d Parachute Infantry, had passed shortly before. Delayed all morning by enemy machine guns, they did not reach

*--282--*

------------------------------------------------------------------------

<span id="page283"></span>

> their first objective, Houdienville, until early afternoon, after the seaborne troops were already through the exit and proceeding inland.
>
> Meanwhile Colonel Sink, at Culoville, knowing nothing of the 2d Battalion's movements, decided to send his reserve, the 1st Battalion under Colonel Turner, to carry out a part of the mission. Turner's "battalion" of fifty men was ordered to Pouppeville. Again relatively light enemy opposition succeeded in harassing the march and delaying for several hours Turner's arrival on his objective.
>
> In the course of the delay a third unit was sent on the same mission by the division commander, Maj. Gen. Maxwell Taylor,<sup><a href="#fn30" id="cn30">30</a></sup> who had no knowledge of the two previous moves. The 3d Battalion, 501st Parachute Infantry (Lt. Col. Julian Ewell), had been designated to land as division reserve with the additional task of protecting the glider landing zone northwest of Hiesville. Although three planes of the 3d Battalion serial were shot down with the loss of three-quarters of their personnel and other planes were scattered by fog and flak, enough carried out their scheduled drops so that about 300 men of the battalion and of the division headquarters were able to assemble quickly and establish the division command post as planned near Hiesville. From there Colonel Ewell, with a group of about forty men from the line companies and some miscellaneous headquarters personnel, was sent at 0600 to clear the Pouppeville beach exit.
>
> At about 0800 Ewell's men reached Pouppeville and attacked to clean it out. The enemy force of approximately sixty to seventy men of the *1058th Regiment* (*91st Division*)<sup><a href="#fn31" id="cn31">31</a></sup> did not offer determined resistance, but it was nevertheless a slow task for the numerically inferior Americans to fight them house to house. It was noon before the local German commander surrendered. The Americans had suffered eighteen casualties, while inflicting twenty-five on the enemy and taking thirty-eight prisoners. The rest of the enemy in Pouppeville retreated toward the beach where they were caught by the advancing U.S. seaborne forces, and at last surrendered to the 8th Infantry. The first contact between seaborne and airborne forces was made at Pouppeville between Colonel Ewell's men and the 2d Battalion, 8th Infantry (Lt. Col. Carlton O. MacNeely).
>
> Throughout D Day Colonel Sink at the 506th regimental headquarters felt wholly isolated and almost alone on the Cotentin Peninsula. Most of the time he was out of touch with his own battalions and with the division; he had little information about the enemy, and his headquarters was involved in scattered fights for its own security. The regiment unknowingly had set up in the midst of a small hornet's nest. In the Ste. Marie-du-Mont area was the entire *2d Battalion* of the *191st Artillery Regiment* which had been committed to coastal defense in the *709th Division* sector.<sup><a href="#fn32" id="cn32">32</a></sup> The battalion headquarters was in Ste. Marie

*--283--*

------------------------------------------------------------------------

<span id="page284"></span>

> and the three batteries, each with four 105-mm. howitzers, were all in the immediate vicinity. Four of the pieces were captured near Holdy by groups of the 1st Battalion, 506th Infantry. The enemy battalion headquarters was overrun by combined action of the 506th Infantry and elements of the 4th Division later in the day.<sup><a href="#fn33" id="cn33">33</a></sup> For the most part, however, Colonel Sink had no men to spare either to clear the enemy from his immediate vicinity or even to reconnoiter to make contact with other friendly units. He believed it necessary to keep together his handful of men to protect the rear of the units engaged in clearing the causeways and to provide a nucleus for concentration of the regiment. The group maintained itself, fighting off enemy riflemen who twice during the day closed in among the surrounding hedgerows. In the evening, with forces of the 1st and 2d Battalions, Colonel Sink controlled about 650 men.
>
> The hedgerows, which bottled up Colonel Sink's men in apparent isolation despite the nearness of friendly units, were to become the most important single preoccupation of American fighting men during their next two months in Normandy and would remain as their most vivid memory of the land. These hedgerows, ubiquitous throughout the Cotentin and the *bocage* country, were earth dikes averaging about four feet in height and covered with tangled hedges, bushes, and even trees. Throughout the entire country they boxed in fields and orchards of varying sizes and shapes, few larger than football fields and many much smaller. Each hedgerow was a potential earthwork into which the defenders cut often-elaborate foxholes, trenches, and individual firing pits. The dense bushes atop the hedgerows provided ample concealment for rifle and machine gun positions, which could subject the attacker to devastating hidden fire from three sides. Observation for artillery and mortar fire was generally limited to a single field, particularly in the relatively flat ground of the beachhead areas. Each field thus became a separate battlefield which, when defended with determination, had to be taken by slow costly advances of riflemen hugging the hedgerows to close with the enemy with rifle and grenade. Both Americans and Germans complained that the hedgerows favored the other side and made their own operations difficult. In fact, the country was ideal for static defense and all but impossible for large coordinated attacks or counterattacks. The chief burden of the fighting remained with the individual soldier and the advance of his unit depended substantially on his own courage and resourcefulness, and above all on his willingness to move through machine gun and mortar fire to root the enemy out of his holes.
>
> The 101st Airborne Division within a relatively few hours of landing had secured the western edge of the inundated area west of UTAH Beach. The task was accomplished, not quite according to plan, but on time and with much smaller cost than anyone had thought possible before the operation.<sup><a href="#fn34" id="cn34">34</a></sup> The remaining

*--284--*

------------------------------------------------------------------------

<span id="page285"></span>

> <a href="img/USA-E-XChannel-43.jpg" target="mapwindow"><img src="icn/USA-E-XChannel-43.jpg" /></a>
>
> HEDGEROW COUNTRY. *Aerial view (above) of typical hedgerow terrain in Normandy; and (below) infantry crouching behind the bushes atop hedgerow.*
>
> <a href="img/USA-E-XChannel-44.jpg" target="mapwindow"><img src="icn/USA-E-XChannel-44.jpg" /></a>

*--285--*

------------------------------------------------------------------------

<span id="page286"></span>

> part of the division's D-Day task was to seize and occupy the line of the Douve River on either side of Carentan, initially to protect the southern flank of VII Corps and later to drive southward through Carentan to weld together the VII and V Corps beachheads.
>
> The 3d Battalion, 506th Parachute Infantry, was to drop south of Vierville, seize two bridges over the Douve at le Port, and establish a bridgehead on the south bank of the river. Its mission came perilously near failure at the outset. The enemy, fully alerted before the drop, not only put up a heavy antiaircraft barrage but illuminated the drop zone by setting fire to an oil-soaked building near by. Paratroopers that landed in the area were greeted by a concentration of machine gun bullets and mortar shells. Others, experiencing delayed drops, came down in or near the swamplands east of the drop zone.
>
> The battalion S-3, Capt. Charles G. Shettle, landing near Angoville-au-Plain, collected two officers and twelve men and then proceeded at once across the flat marshy river plain toward his objective. By the time he reached the bridge at Brevands at 0430 he had picked up a total of thirty-three men, and was there reinforced by twenty more a little later and by another forty during the night of 6-7 June. Shettle's group established themselves first on the southeast bank of the river but could not hold the position in the face of increasing enemy machine gun fire. They therefore withdrew across the river and dug in on the northwest bank. During the day the enemy did not counterattack; in the middle of the night he made only a halfhearted push toward the bridge, from which he readily backed off when the Americans opened fire. The situation at Brevands on D Day paralleled that on the northern flank where the 502d Parachute Infantry was also holding a tenuous line facing superior enemy forces. Both defenses succeeded chiefly by grace of the enemy's reluctance to leave his prepared positions and attack, and his confusion as to American strength and intentions. It is worth observing, however, that the Carentan canal was the boundary between the *709th* and *352d Divisions.* The latter, located to the south, would not attack across the canal without orders from corps. Corps, in fact, had ordered the reserve unit, the *6th Parachute Regiment* to make such an attack from the south but it did not at once come into action.<sup><a href="#fn35" id="cn35">35</a></sup>
>
> Completion of the 101st Division's defense of the Douve River line west to St. Côme-du-Mont was the task of the 501st Parachute Infantry (Col. Howard R. Johnson) less the 3d Battalion. The regiment's missions in detail were to seize the lock at la Barquette, blow the bridges on the St. Côme-du-Mont-Carentan road, take St. Côme-du-Mont if possible, and destroy the railroad bridge to the west. Of these objectives the lock at la Barquette had a special importance for the planners.
>
> The purpose of the lock was to permit the controlled flow of the tide up the river channel so as to maintain a depth sufficient for barge navigation as far upstream as St. Sauveur-le Vicomte. If the lock were destroyed the swamplands of the Douve and Merderet would suffer erratic tidal flooding. On the other

*--286--*

------------------------------------------------------------------------

<span id="page287"></span>

> hand, partial obstruction of the lock would permit controlled flooding of the same area by backing up the river flow. The latter kind of inundation had been effected by the Germans before D Day. Capture of the lock, it was believed, was tactically important in order that VII Corps might control the Douve and Merderet inundations, which together constituted a barrier to military movement across the whole eastern half of the base of the peninsula. The importance was stressed even though it was recognized that flooding and draining of the area were slow processes and that the natural swamps and flat bottomlands, crisscrossed with drainage ditches, in themselves formed a convincing obstacle to vehicle movement and a grave hindrance to infantry maneuver.
>
> Just before D Day the drop zone for the 501st Parachute Infantry (and the 3d Battalion, 506th) had been shifted about a mile and a half southeast-from the vicinity of Beaumont to east and south of Angoville-au-Plain-in order to bring the paratroopers down nearer their objective and avoid the antiairlanding obstacles which last-minute reconnaissance had discovered on the original drop zone. The change does not seem to have been responsible for the inaccuracy of the drop. The scattering of the 1st Battalion planes resulted from the same conditions of fog and enemy antiaircraft fire which had affected all the other airborne units and was certainly no more serious. What was serious, however, was the loss in the drop of the entire battalion command. The commanding officer was killed; the staff and all the company commanders were missing from the first critical battles.
>
> Colonel Johnson, the regimental commander, by good fortune landed about where he was supposed to and, in the process of moving southward toward la Barquette, managed to collect some 150 men of miscellaneous units with whom he set out to accomplish his mission. The first step went well. Before the enemy had been fully alerted, a portion of the force crossed the lock and dug in on the far side. They seemed relatively secure there as the enemy made no attempt to press in on them. Colonel Johnson therefore decided to try to get the Douve bridges to the west. With fifty men he first went north to Basse Addeville, where he had ascertained that a considerable number of paratroopers had assembled under Maj. Richard J. Allen, the regimental S-3.- Although Allen's men were already in contact with the enemy to the north and west, it proved possible to assemble about fifty of them in the early afternoon to return with Colonel Johnson to la Barquette. Met by intense enemy artillery, mortar, and small arms fire, chiefly from the rear, the force called for naval fire support through a naval shore fire control officer who had initially joined Major Allen's unit at Addeville. Salvos from the 8-inch guns of the *Quincy* adjusted on enemy positions around St. Côme-du-Mont caused almost immediate slackening of the enemy fire. At about 1500 Major Allen was ordered to bring the rest of his force to the lock and he joined Colonel Johnson an hour or two later.<sup><a href="#fn36" id="cn36">36</a></sup>

*--287--*

------------------------------------------------------------------------

<span id="page288"></span>

> Even with this support, however, it proved impossible to advance westward to the Douve bridges. The *3d Battalion* of the *1058th Regiment* held St. Côme-du-Mont and the surrounding ground in force and strongly resisted with fire every move in that direction. The opposition here in the sector of the *91st Division* and immediately to the south where the *6th Parachute Regiment* held Carentan and the road and rail bridges was much more determined than anywhere in the coastal sector held by the *709th Division.*
>
> The unexpected strength of the enemy in the Carentan--St. Côme-du-Mont area had been discovered by the 2d Battalion, 501st Parachute Infantry (Lt. Col. Robert A. Ballard), shortly before Colonel Johnson tried unsuccessfully to move westward. Colonel Ballard had assembled parts of his lettered companies and his battalion staff between Angoville-au-Plain and les Droueries. Since his assigned mission was the destruction of the Douve bridges above Carentan, he began at once an attack toward St. Côme-du-Mont. The companies, of about thirty men each, ran into strong opposition in the hamlet of les Droueries, which they had attacked frontally in the belief that not more than an enemy platoon faced them. After they were turned back initially, a renewed flanking attack was meeting some success when Colonel Ballard was ordered by Colonel Johnson to move to la Barquette to participate in the drive from that point toward the Carentan highway. The 2d Battalion disengaged but, in attempting to move south through Addeville, was stopped almost immediately by heavy fire from the same enemy force that had opposed the attack on les Droueries. Ballard's men remained during the night in close contact with the enemy. In the meantime, Colonel Johnson, abandoning for the time the attempt to get to the Douve bridges, consolidated the position at la Barquette, deepening the southern bridgehead, pushing out his flanks, and maintaining contact with the 3d Battalion, 506th Parachute Infantry, on the east. Patrols during the night of 7 June were sent out to try to find the 506th Regiment and division headquarters, but they did not succeed and the southern line remained isolated and precariously held by groups equivalent to about three companies instead of three battalions as planned.
>
> By the end of D Day the 101st Airborne Division had assembled only about 2,500 of the 6,600 men-who had dropped during the early morning hours.<sup><a href="#fn37" id="cn37">37</a></sup> They were distributed in mixed units of varying size. But despite the handicaps of scattered landings and heavy losses in both men and equipment the division had carried out the most important of its D-Day tasks. Above all, the paratroopers had succeeded in clearing the way for the move of the seaborne forces inland. This was the task which had been considered so vital to the whole Allied invasion plan as to warrant the extraordinary

*--288--*

------------------------------------------------------------------------

<span id="page289"></span>

> risk of airborne landings in heavily defended enemy territory. If the division's defensive line north and south was weak, that weakness was for the moment balanced by the enemy's failure to organize concerted counterattacks.
>
> The position of the 82d Airborne Division (Maj. Gen. Matthew B. Ridgway)<sup><a href="#fn38" id="cn38">38</a></sup> on the west was cause for far greater concern both to General Ridgway and to the Allied command. Landing on the edge of the assembly area of the German *91st Division,* it met more determined opposition in the early stages. It suffered more seriously also from scattered drops which left two of its regiments unable to assemble in sufficient force to carry out their missions.
>
> By the revised plan of 28 May, Ridgway's division was ordered to drop astride the Merderet River, clear the western portion of the beachhead area between the sea and the Merderet and from the Douve River north to Ste. Mère-Eglise, and establish a bridgehead on the west bank of the Merderet. One parachute regiment (the 505th) was to capture Ste. Mère-Eglise, secure crossings of the Merderet near la Fière and Chef-du-Pont, and establish a defensive line north from Neuville-au-Plain to Beuzeville-au-Plain to tie in with the 502d Parachute Infantry of the 101st Airborne Division. The other two regiments (507th and 508th), dropping west of the river, were to consolidate the two 505th bridgeheads and push out a defensive line about three miles westward, anchored on the south at the crossroads just west of Pont l'Abbé and thence extending north in an arc through Beauvais. The 507th Parachute Infantry would defend the line of the Douve, destroying bridges at Pont l'Abbé and Beuzeville-la-Bastille. Both regiments would be prepared to attack west in the direction of St. Sauveur-le Vicomte.
>
> Only one of the 82d Airborne Division's missions was carried out according to plan: the capture of Ste. Mère-Eglise. Success at Ste. Mère-Eglise was due in part to the exceptionally good drop of the 505th Parachute Infantry northwest of the city. (<a href="maps/USA-E-XChannel-X.jpg" target="mapwindow"><em>Map X</em></a>) Most of the regiment's planes, though initially scattered like the others, were able to circle back and release the paratroopers over the drop zone which pathfinders had clearly marked. In addition the regiment had the good fortune to come down in an area devoid of enemy. The 3d Battalion (Lt. Col. Edward C. Krause), which was to take the town of Ste. Mère-Eglise, rapidly assembled about a quarter of its men and moved out in the early morning hours. Counting on speed and surprise, Colonel Krause ordered his men to enter the town without a house-to-house search and to use only knives, bayonets, and grenades while it was still dark so that enemy gunfire could be spotted. The enemy was caught off balance and before dawn the town had fallen--the first prize for American arms in the liberation of France. Resistance had been slight: when Ste. Mère-Eglise was cleared Krause's men counted only ten enemy dead and about thirty prisoners. The battalion cut the main Cherbourg

*--289--*

------------------------------------------------------------------------

<span id="page290"></span>

> communications cable and established a perimeter defense of the town.
>
> The 2d Battalion, 505th Parachute Infantry (Lt. Col. Benjamin H. Vandervoort), in the meantime had assembled half of its men and was moving northward to establish the regimental defense line through Neuville-au-Plain and Bandienville. (See <a href="maps/USA-E-XChannel-VIII.jpg" target="mapwindow"><em>Map VIII</em></a>.) At 0930 the enemy counterattacked Ste. Mère-Eglise from the south and the regimental commander, Col. William E. Ekman, ordered his 2d Battalion back to aid in the defense. Before turning back Colonel Vandervoort detached a platoon under Lt. Turner B. Turnbull and sent it to organize a defense at Neuville which was reported to be lightly held by the enemy. Turnbull moved through the town without opposition and deployed his men on the high ground north of the town. He was hardly in position before the enemy attacked with a force outnumbering the defenders about five to one. The platoon fought stubbornly and for eight hours held its ground. The small action had a significance which Turnbull did not realize at the time. The fight at Neuville kept the enemy in the north at arm's length while the defenders of Ste. Mère-Eglise beat off the simultaneous enemy attack from the south. The cost of the platoon's gallant stand was heavy. Only sixteen of the forty-two men who had gone to Neuville-au-Plain survived to be withdrawn late in the afternoon to rejoin their battalion.
>
> In Ste. Mère-Eglise the 2d Battalion of the 505th on its arrival at about 1000 took over the northern half of the perimeter defense, permitting the 3d Battalion to strengthen its position on the south. Two companies were held in reserve inside the town. By agreement between the battalion commanders, Colonel Krause took charge of the defense. The first enemy thrust up the Carentan road, made in strength of about two companies supported by some armor, was repulsed. Krause then ordered a counterattack. Company I with eighty men was instructed to move out south, turn east, and hit the flank of the enemy, whose main positions were astride the highway. The attack, however, hit only a single enemy convoy moving southward. Having destroyed the convoy with grenades, Company I returned to Ste. Mère-Eglise. The enemy made no further serious effort during the day to dislodge the Americans.<sup><a href="#fn39" id="cn39">39</a></sup>
>
> The prompt occupation of Ste. Mère-Eglise and its defense were a boon for which the 82d Airborne Division had increasing reason to be grateful as the day's actions along the Merderet River developed. The establishment of bridgeheads over the Merderet was the mission of the 1st Battalion of the 505th Parachute Infantry, attacking from the regiment's drop zone east of the river. Ultimate success in this mission, however, depended on the ability of the 507th and 508th Parachute Infantry Regiments to occupy the west bank of the river in force. The 507th and 508th drop zones lay in the triangle at the confluence of the Douve and Merderet Rivers--an area of about twelve square miles--and along the outer perimeter of the VII Corps planned beachhead. Presence of the enemy in the scheduled drop zones prevented the pathfinders from marking them, and the pilots of the two regimental serials, looking in vain for the markers, in most cases delayed

*--290--*

------------------------------------------------------------------------

<span id="page291"></span>

> flashing the jump lights until they had overshot the zones. Both regiments were thus widely dispersed and many paratroopers, heavily laden with equipment, dropped in the swamplands along the river.
>
> Absorbed naturally with the basic problem of assembling, these paratroopers tended to collect along the embankment of the main railroad from Cherbourg to Carentan, both because it was high dry ground and because it was a recognizable terrain feature. By following this embankment south, they crossed the river and arrived in the vicinity of la Fière with the river between them and their objectives. The only large group which, under command of Brig. Gen. James A. Gavin, Assistant Division Commander, tried to push down along the edge of the swamps on the west bank of the river was delayed in starting until dawn by vain efforts to recover equipment from the swamps. With daylight, enemy fire west of the river became intense. Gavin therefore had to give up the attempt and moved his men on down the embankment to join the others west of Ste. Mère-Eglise.<sup><a href="#fn40" id="cn40">40</a></sup>
>
> By the middle of the morning 500 to 600 men of miscellaneous units had gathered at la Fière, which was one of the two known crossings of the Merderet in the 82d Airborne Division zone. The la Fière crossing was an exposed narrow causeway raised a few feet above the river flats and extending 400 to 500 yards from the bridge over the main river channel to the gently rising hedgerow country of the west shore.
>
> Two of the first groups on the scene, portions of Company A of the 505th and a group mostly of the 507th Parachute Infantry under Lt. John H. Wisner, had tried to rush the bridge in the early morning but were repulsed by machine gun fire. When General Gavin arrived, he decided to split the la Fière force and sent seventy-five men south to reconnoiter another crossing. Later, receiving word that the bridge at Chef-du-Pont was undefended, he took another seventy-five men himself to try to get across there. The groups remaining at la Fière made no progress for several hours. Then General Ridgway, who had landed by parachute with the 505th, ordered Col. Roy Lindquist, the commanding officer of the 508th Parachute Infantry, to organize the miscellaneous groups and take the bridge.<sup><a href="#fn41" id="cn41">41</a></sup>
>
> In the meantime west of the river about fifty men of the 2d Battalion, 507th Parachute Infantry, had collected under the battalion commander, Lt. Col. Charles J. Timmes. Shortly after the drop, Timmes had passed through Cauquigny, the tiny village at the west end of the la Fière causeway. But he did not stay. Hearing firing in the direction of Amfreville, he reckoned that paratroopers were attacking the village from the north and decided to support the attack by advance from the east. His estimate proved wrong; the enemy firing was actually directed against his own group. Unable to proceed toward the village Timmes withdrew his men to a

*--291--*

------------------------------------------------------------------------

<span id="page292"></span>

> position along the river east of Amfreville and began to dig in. When the position was organized about midmorning, he sent a patrol of ten men back to Cauquigny to establish a fire position to dominate the west end of the la Fière causeway. The patrol set up a machine gun in the Cauquigny church, and awaited developments.<sup><a href="#fn42" id="cn42">42</a></sup>
>
> At noon the forces around la Fière gathered for a coordinated three-company attack. In two hours one company under Capt. F. V. Schwarzwalder succeeded in carrying the attack across the causeway, and established contact with Timmes' patrol. The way was then open to consolidating the bridgehead and completing one of the most important of the 82d Airborne Division's missions. The initial success, however, was not followed up. Probably because it was difficult in the hedgerow country for any unit to tell quickly what was going on beyond its immediate limited observation, the first crossing by about seventy-five men was not immediately reinforced. Furthermore Schwarzwalder's company, instead of holding on the west bank, decided to proceed on to Amfreville to join the 2d Battalion, 507th Parachute Infantry, to which most of the men belonged. As Schwarzwalder move out, the enemy began to react to the initial American attack with artillery, small arms fire, and at last a tank sally.<sup><a href="#fn43" id="cn43">43</a></sup> It was in the middle of this counterattack that belated American reinforcements arrived on the west bank and were immediately disorganized and beaten back. The bridge was lost. Colonel Timmes' group east of Amfreville reinforced by Schwarzwalder's company was isolated under heavy and continuing enemy pressure which effectively prevented it for the next two days from any further active attempts at accomplishing the division's mission. The enemy tried to follow up his advantage with attacks across the causeway. These netted him only temporary footholds on the east bank but during the day compelled the Americans to bring back most of the troops sent earlier to probe out crossings of the river to the south.
>
> While the la Fière bridge was won and lost, the attempt to cross at Chef-du-Pont about two miles south had reached a temporary deadlock, as a relatively small number of Germans dug in along the causeway tenaciously resisted all efforts to dislodge them.<sup><a href="#fn44" id="cn44">44</a></sup> Late in the afternoon, after most of the paratroopers had been recalled to strengthen the la Fière position, the under-strength platoon left at Chef-du-Pont under Capt. Roy E. Creek was threatened with annihilation by an enemy counterattack. Under heavy direct fire from a field piece on the opposite bank and threatened by German infantry forming for attack on the south, Creek's position seemed desperate. At that moment a glider bearing an antitank gun landed fortuitously in the area. With this gun the enemy was held off while about a hundred paratroopers, in response to Creek's plea for reinforcements, came down from la Fière. The reinforcements gave Creek strength enough to beat off

*--292--*

------------------------------------------------------------------------

<span id="page293"></span>

> the Germans, clear the east bank, and finally cross the river and dig in. This position, however, did not amount to a bridgehead and Creek's tenuous hold on the west end of the causeway would have meant little but for the action of the 508th Parachute Infantry west of the river.
>
> Elements of the 508th, amounting to about two companies of men under command of Lt. Col. Thomas J. B. Shanley, commanding officer of the 2d Battalion, were the most important of at least four groups of paratroopers who assembled west of the Merderet but who for the most part, being forced to fight for survival, could contribute little toward carrying out planned missions. Dropped near Picauville, Colonel Shanley gathered a small force of paratroopers--too small to proceed with his mission of destroying the Douve bridge at Pont l'Abbé. He tried during the day to join other groups in the vicinity with whom he had radio contact, but under constant enemy pressure he was unable to effect a junction until late in the day. It had then become apparent to him that he was engaged with an enemy force of at least battalion strength, and he decided to withdraw to the battalion assembly area on Hill 30. In fact, the Germans, elements of the *1057th Regiment,* had been pushing eastward in this area most of the day under orders to counterattack in order to wipe out American parachutists west of the Merderet. Colonel Shanley's resistance undoubtedly helped save the forces at la Fière and Chef-du-Pont. Once he was firmly established on Hill 30, he formed a valuable outpost against continuing German attacks and a few days later would be in position to contribute substantially to establishing the Merderet bridgehead. For Colonel Shanley's success three enlisted men have received a large share of the credit. They were Cpl. Ernest T. Roberts, Pvt. Otto K. Zwingman, and Pvt. John A. Lockwood who, while on outpost duty in buildings at Haut Gueutteville, observed the forming of a German counterattack by an estimated battalion of infantry with tank support. They stayed at their posts holding off the enemy attack for two hours and allowing the main body of Shanley's force to establish an all-around defense at Hill 30.<sup><a href="#fn45" id="cn45">45</a></sup>
>
> As reports of the airborne landings came in to the German *Seventh Army* headquarters and the extent of the landings became apparent, General Dollmann ordered a series of moves designed to seal off the airhead and destroy it. (<a href="maps/USA-E-XChannel-2.jpg" target="mapwindow"><em>Map 2</em></a>) The *709th Division* with the *1058th Regiment* (*91st Division*) attached was ordered to clear the area east of the Merderet.<sup><a href="#fn46" id="cn46">46</a></sup> At the same time the *91st Division* counterattacked from the west using the *1057th Regiment* and the *100th Panzer Replacement Battalion* in an attempt to wipe out paratroopers who had landed west of the inundated area. The *6th Parachute Regiment* under control of the *91st Division* was to attack through Carentan from the south.<sup><a href="#fn47" id="cn47">47</a></sup> Finally at the end of the

*--293--*

------------------------------------------------------------------------

<span id="page294"></span>

> <a href="img/USA-E-XChannel-46.jpg" target="mapwindow"><img src="icn/USA-E-XChannel-46.jpg" /></a>  
> MERDERET RIVER CROSSING *at Chef-du-Pont. Village of les Merieux is in lower right-hand corner of picture.*

*--294/295--*

------------------------------------------------------------------------

<span id="page296"></span>

> <span id="map2"></span>
>
> <a href="maps/USA-E-XChannel-2.jpg" target="mapwindow"><img src="maps/USA-E-XChannel-2m.jpg" /></a>  
> GERMAN COUNTERATTACK IN THE COTENTIN. *Reproduction of a captured *OB WEST* map dated 6-7 June 1944.*

*--296--*

------------------------------------------------------------------------

<span id="page297"></span>

> day the *Seventh Army* *Sturm Battalion* was ordered to move against the American bridgehead from the vicinity of Cherbourg, attacking in the direction of Ste. Mère-Eglise. A regiment of the *243d Division* was ordered to move by night to Montebourg.<sup><a href="#fn48" id="cn48">48</a></sup> By means of these moves and concentric counterattacks Dollmann was sure at first that he could cope with the Cotentin landings without moving in any additional forces. It was only in the evening that his optimism waned, as the *91st Division* reported that its counterattack was making very slow progress because of the difficulties of maneuvering in the hedgerow country. In fact the attack had scarcely materialized at all except in local actions along the Merderet.
>
> Similarly the *1058th Regiment,* apparently harassed by scattered American paratroopers, could not get moving in its attack toward Ste. Mère-Eglise. By evening its advance elements were still north of Neuville-au-Plain. Generalleutnant Karl-Wilhelm von Schlieben, commander of the *709th Division,* ordered it to resume the attack on Ste. Mère-Eglise the next morning. He attached to it two motorized heavy artillery battalions, the *456th* and *457th* (each with two 150-mm. guns and a battery of Russian 122-mm. guns), and the company of self-propelled guns of the *709th Antitank Battalion.*<sup><a href="#fn49" id="cn49">49</a></sup>
>
> For the general sluggishness of German reaction in the Cotentin, there seem to be several explanations. In the first place two of the three division commanders, von Schlieben and Generalleutnant Wilhelm Falley (of the *91st Division*), together with some of the subordinate commanders, were at Rennes attending a war game when the invasion struck. Schlieben did not get back to his headquarters near Valognes until noon. Falley on his return was killed by paratroopers. To the uncertainty caused by the commanders' absence was added the confusion of disrupted communications. Von Schlieben, for instance, during the day had no contact with two of his battalions in the thick of the fighting, the *1st Battalion,* *919th Regiment,* in the UTAH Beach area, and the *795th Georgian Battalion* near Turqueville. In attempting counterattacks against scattered U.S. riflemen the Germans experienced the same difficulties with the hedgerow country that the Americans did. Finally the *LXXXIV Corps* headquarters, far away in St. Lô, could not exercise effective control and coordinate the action of the three divisions in the peninsula. On the other hand communications were not set up to enable the division commanders to effect their own coordination.<sup><a href="#fn50" id="cn50">50</a></sup>
>
> The experience of the *6th Parachute Regiment* illustrates in striking fashion the confusion and lack of coordination in the initial German reactions and throws a strange half-light on the D-Day battles in the Cotentin. The commander of the regiment, Major Friedrich-August Freiherr von der Heydte, was at his command post north of Periers when the Allied landings began. But telephone lines to the *91st Division* and to *LXXXIV Corps* were broken during the night by open action of the French Resistance. It was not until about 0600 that von der

*--297--*

------------------------------------------------------------------------

<span id="page298"></span>

> Heydte was able to reach General Marcks at *LXXXIV Corps* headquarters by a private line and get his orders, which were to attack with his regiment through Carentan and clean out the rear area of the *709th Division* between Carentan and Ste. Mère-Eglise. Von der Heydte arrived in Carentan in the morning and found no Allied troops and very few Germans. He got in touch with his battalions and ordered them to assemble southwest of Carentan. He then climbed the church steeple in St. Côme and looked around. The picture before him was, he said, overwhelming. He could see the Channel and the armada of Allied ships, covering the water to the horizon. He could see hundreds of small landing craft plying to the shore unloading men and tanks and equipment. Yet, for all that, he got no impression of a great battle in progress. It was then about noon. The sun was shining. Except for a few rifle shots now and then it was singularly quiet. He could see no Allied troops. The whole scene reminded him of a summer's day on the Wannsee.<sup><a href="#fn51" id="cn51">51</a></sup>
>
> It was apparently his impression that no seaborne U.S. troops had come inland in the direction of St. Côme. In accordance with that impression he made his dispositions. He ordered his battalions to come up to St. Côme; the *2d Battalion* was then instructed to proceed to Ste. Mère-Eglise and attack and destroy any enemy encountered. The *1st Battalion* was to move to the high ground near Ste. Marie-du-Mont and protect the regiment from any enemy thrusts inland from the sea. The *3d Battalion* was to return to Carentan to provide the regiment with a defense in depth, and the attached *3d Battalion,* *1058th Regiment,* was to remain with von der Heydte in St. Côme-du-Mont. The *1st* and *2d Battalions* moved out at about 1900. By midnight the *1st Battalion* had marched apparently without serious trouble through the territory occupied by the 101st Airborne Division and reached the vicinity of Ste. Marie-du-Mont. The *2d Battalion* moved north and possibly reached the vicinity of Fauville. Both battalions sent a number of American prisoners back to the regimental headquarters.
>
> During the night the landing of U.S. glider reinforcements impressed von der Heydte as new large-scale airborne landings. They cut off the *2d Battalion* from the regiment and from the *1st Battalion.* (In reality, both battalions were already cut off by the advance of the 8th Infantry inland, but this development was apparently unknown to von der Heydte.) He ordered the battalions to maintain contact with each other and pull back to form a crescent defense of St. Côme. Only the *2d Battalion* acknowledged receipt of the order and reported that it was not in touch with the *1st Battalion.* As for the *1st Battalion,* it set out on the morning of 7 June to rejoin the regiment, moving south toward Carentan. It never got there, for at the Douve River it ran into the 101st Airborne Division units and surrendered almost to a man.<sup><a href="#fn52" id="cn52">52</a></sup>
>
> The experience of the *6th Parachute Regiment* was typical of the inability of the German forces to concentrate against the landings, even when, as in the case of

*--298--*

------------------------------------------------------------------------

<span id="page299"></span>

> <a href="img/USA-E-XChannel-47.jpg" target="mapwindow"><img src="icn/USA-E-XChannel-47.jpg" /></a>
>
> CROSSING THE CHANNEL. *Columns of LCI(L)'s (above) heading for the French coast, and troops on deck of LCI(L) (below) on D-Day morning.*
>
> <a href="img/USA-E-XChannel-48.jpg" target="mapwindow"><img src="icn/USA-E-XChannel-48.jpg" /></a>

*--299--*

------------------------------------------------------------------------

<span id="page300"></span>

> the 82d Airborne Division, they were scattered and relatively weak. Thanks to this failure, the 82d was able to maintain itself while it gradually built back its strength. At the end of D Day, the division was strongly ensconced in the vicinity of Ste. Mère-Eglise but was precariously situated outside the main VII Corps beachhead. It had no contact with the 101st Airborne or 4th Infantry Divisions. It had assembled only a fraction of its own men. Planned seaborne reinforcements had not arrived. The bulk of the glider reinforcements (the 325th Glider Infantry) were not due until the next morning. At the end of the day, the division reported that it controlled only 40 percent of its combat infantry and 10 percent of its artillery.<sup><a href="#fn53" id="cn53">53</a></sup> The first estimate sent on to VII Corps indicated total casualties of about four thousand.<sup><a href="#fn54" id="cn54">54</a></sup> The bulk of these, however, were the missing paratroopers scattered far and wide in enemy territory. Revised calculations in August 1944 showed D-Day losses of 1,259 including 156 known killed and 756 missing, presumed captured or killed.<sup><a href="#fn55" id="cn55">55</a></sup>
>
> ### *Hitting the Beaches*
>
> While U.S. airborne troops dropped on the Cotentin and British paratroopers landed near Caen, the invasion fleet was bringing the main body of the Allied armies to the shores of Normandy. The assault convoys, after turning back for the day's postponement, reassembled during the morning of 5 June and sailed again for the transport areas 22,000 to 23,000 yards off the French coast in the Bay of the Seine. Behind mine sweepers which cleared and marked ten lanes through old enemy mine fields in the Channel, the huge convoys, under constant air umbrella of fighter squadrons flying at 3,000 to 5,000 feet, made an uneventful voyage unmolested by the enemy either by air or sea.<sup><a href="#fn56" id="cn56">56</a></sup> H Hour for U. S. beaches was 0630.
>
> The weather was still cause for concern. During the passage a gusty wind blowing from the west at fifteen to twenty knots produced a moderately choppy sea with waves in mid-Channel of from five to six feet in height. This was a heavy sea for the small craft, which had some difficulty in making way. Even in the assault area it was rough for shallow-draft vessels, though there the wind did not exceed fifteen knots and the waves averaged about three feet. Visibility was eight miles with ceiling at 10,000 to 12,000 feet. Scattered clouds from 3,000 to 7,000 feet covered about half the sky over the Channel at H Hour becoming denser farther inland. Conditions in short were difficult though tolerable for both naval and air forces.<sup><a href="#fn57" id="cn57">57</a></sup>
>
> Most serious were the limitations on air operations. Heavy bombers assigned to hit the coastal fortifications at OMAHA Beach had to bomb by instruments through the overcast. With concurrence of General Eisenhower the Eighth Air Force ordered a deliberate delay of several seconds in its release of bombs in order to insure that they were not dropped among the assault craft. The result was that the 13,000

*--300--*

------------------------------------------------------------------------

<span id="page301"></span>

> bombs dropped by 329 B-24 bombers did not hit the enemy beach and coast defenses at all but were scattered as far as three miles inland. Medium bombers visually bombing UTAH Beach defenses from a lower altitude had slightly better results, although about a third of all bombs fell seaward of the high-water mark and many of the selected targets were not located by pilots. Of 360 bombers dispatched by IX Bomber Command, 293 attacked UTAH Beach defenses and 67 failed to release their bombs because of the overcast. On the whole the bombing achieved little in neutralizing the coastal fortifications.
>
> At about 0230 the *Bayfield,* headquarters ship for Task Force U (Rear Adm. Don P. Moon) and VII Corps (Maj. Gen. J. Lawton Collins), dropped anchor in the transport area off UTAH Beach. Twenty minutes later the *Ancon,* flagship of Admiral Hall and headquarters ship for Task Force O and V Corps, reached the OMAHA Beach transport area. Unloading of assault troops into the LCVP's that would take them to the beaches began.
>
> Up to this point there had been virtually no enemy reaction. The German radar stations still in operation had failed to pick up either the air or the sea approach. Because of bad weather Admiral Krancke had no patrol boats in the Channel during the night, nor did he order them out after he heard of the airborne landings. Tidal conditions would not permit them to leave the harbors before daylight and, besides, Krancke was still not sure that a major attack was in progress. Shortly after three o'clock, however, *Naval Commander Normandy* reported sighting ten large craft lying some seven miles off the coast north of Port-en-Bessin. This news, in conjunction with an increasingly sharp definition of the extent of the airborne landings, at last convinced Admiral Krancke that he was confronting a large-scale landing. He gave such orders as he could. The *Western Defense Forces* were to patrol the coastal waters; the *Landwirt* submarines were to be alerted; the *8th Destroyer Flotilla* was to move up from Royan to Brest; the *5th Torpedo Boat Flotilla* was to reconnoiter the Orne estuary area; and the *9th Torpedo Boat Flotilla* was to patrol off Cap de la Hague. The torpedo boats of the *5th Flotilla* left Le Havre at 0430, but an hour out of port they met six Allied warships escorted by 15 to 20 destroyers. After firing torpedoes at the Allied vessels, the small German boats were attacked from the air. They succeeded in driving off the attackers with antiaircraft fire, but then had to return to Le Havre to replenish their load of torpedoes and ammunition. Two torpedo boat flotillas reconnoitering out of Cherbourg were forced by heavy seas to return to port at dawn. This virtually concluded German naval activity for the day. Admiral Krancke wrote in his diary: "It was only to be expected that no effective blow could be struck at such a superior enemy force."<sup><a href="#fn58" id="cn58">58</a></sup> He made plans, however, to attack the Allied fleet that night.
>
> German coastal batteries began sporadic firing at 0535, or only fifteen minutes before Allied naval bombardment opened prearranged counterbattery fire. Projectiles from Allied battleships and cruisers and destroyers continued to thunder over the heads of the troops making the final run-in to shore until a few minutes before the touchdown. Beach drenching

*--301--*

------------------------------------------------------------------------

<span id="page302"></span>

> was then taken up by the close-support craft. Although the time schedule went generally according to plan on both American beaches, the volume of fire laid down on vital targets was considerably less at OMAHA than expected. Most enemy coastal defenses were sited to cover the beaches rather than the sea approaches. They were therefore well concealed from observation from the sea and were correspondingly difficult to hit. The beach drenching seems generally to have missed its targets; a large percentage of the rockets overshot their marks.<sup><a href="#fn59" id="cn59">59</a></sup>
>
> Naval gunfire coupled with the air bombardment, however, had one important effect at OMAHA Beach which was not at first apparent to the assaulting troops. The Germans credit the Allied bombardment with having detonated large mine field areas on which they counted heavily to bar the attackers from penetrating inland between the infantry strong points. Preparatory fire seems also to have knocked out many of the defending rocket pits. But it was supporting naval gunfire after H Hour which made the substantial contribution to the battle, in neutralizing key strong points, breaking up counterattacks, wearing down the defenders, and dominating the assault area.
>
> In the VII Corps zone the 4th Division (Maj. Gen. Raymond O. Barton)<sup><a href="#fn60" id="cn60">60</a></sup> planned to land in column of regiments on a two-battalion front of about 2,200 yards. The 8th Infantry (Col. James A. Van Fleet), with the 3d Battalion of the 22d Infantry attached, would make the initial assault. It would first occupy the high ground along the road between Ste. Marie-du-Mont and les Forges and would be prepared to move with the bulk of its force thereafter westward across the Merderet River in the zone of the 82d Airborne Division. One battalion would be left in the area west of St. Martin to protect the division's north flank until the arrival of the 22d Infantry. The 22d Infantry (Col. Hervey A. Tribolet), next infantry unit to land, beginning at H plus 85 minutes, would turn north from the beaches to seize the causeway across the inundations at les Dunes de Varreville. Continuing the push northwest, the regiment would capture Quinéville and occupy the high ground at Quinéville and Fontenay-sur-Mer. In the center of the beachhead the 12th Infantry (Col. Russell P. Reeder), landing after H plus 4 hours, would advance with two battalions abreast to seize the high ground between Emondeville and the Merderet River. One battalion of the regiment was at first designated as division reserve to pass to division control in the vicinity of Turqueville. By the late May change of plan, following the alteration of the airborne missions, the battalion was instead released to regimental control and the 12th Infantry was assigned the additional mission of seizing a crossing over the Merderet at le Port Brehay just southwest of the regiment's main objective area. One regiment (the 359th Infantry) of the 90th Division, the first follow-up division, was attached to the 4th Division to begin landing on D Day.<sup><a href="#fn61" id="cn61">61</a></sup> It would assemble in reserve

*--302--*

------------------------------------------------------------------------

<span id="page303"></span>

> <a href="img/USA-E-XChannel-49.jpg" target="mapwindow"><img src="icn/USA-E-XChannel-49.jpg" /></a>
>
> TROOPS ON UTAH BEACH. *The troops wading ashore (above) were photographed shortly after H Hour. Note DD tanks on beach. Soldiers (below) take shelter behind sea wall while awaiting orders to move inland.*
>
> <a href="img/USA-E-XChannel-50.jpg" target="mapwindow"><img src="icn/USA-E-XChannel-50.jpg" /></a>

*--303--*

------------------------------------------------------------------------

<span id="page304"></span>

> near Foucarville. In May, enemy activity was observed on the St. Marcouf Islands flanking UTAH Beach on the north. It was therefore decided to land detachments of the 4th and 24th Cavalry Squadrons two hours before H Hour to clean out what was suspected to be an enemy observation post or mine field control point.
>
> The airborne troops had done their job well and the 4th Division therefore had little difficulty getting ashore. The cavalry detachments (132 men) found the St. Marcouf Islands unoccupied though heavily mined. From mines and a concentration of enemy artillery that hit the islands in the afternoon the cavalry units lost two men killed and seventeen wounded.<sup><a href="#fn62" id="cn62">62</a></sup> The small craft (LCVP's) carrying the first waves of the 1st and 2d Battalions of the 8th Infantry were launched in relatively sheltered water and had no serious trouble with the wind and surf. At H Hour there was no enemy opposition. The thirty-two DD tanks supposed to land in the first wave were delayed by the loss of a control vessel that struck a mine. All but four, which were lost when the LCT carrying them hit a mine, were beached approximately fifteen minutes late. But, as it turned out, the assault troops had no immediate need for them.
>
> Leading elements of the two assault battalions touched down approximately on time but almost 2,000 yards south of where they were supposed to land. The error was probably caused in part by the obscuring of landmarks by smoke and dust raised by the naval bombardment and in part by the southeast coastal current. In any case it turned out to be fortunate since it brought troops in on beaches much less heavily defended than those designated in the plan. Although the mislanding meant that the tasks assigned to each assault section could not be carried out as planned, the lack of serious enemy opposition permitted reconnaissance and speedy reorganization for improvised maneuver.<sup><a href="#fn63" id="cn63">63</a></sup> After company-size task forces had reduced the very lightly defended field fortifications covering the two middle beach exits, both assault battalions began their advance across the flooded area. The 1st crossed toward Audouville-la-Hubert; the 2d turned south to pick up the Pouppeville road. (<a href="maps/USA-E-XChannel-3.jpg" target="mapwindow"><em>Map 3</em></a>)
>
> The first infantry wave was followed by engineer and naval demolition parties to clear the underwater obstacles. The obstacles were all dealt with dryshod and were so much sparser that expected that the original plan of blowing fifty-foot gaps were abandoned in favor of clearing the entire beach on the first tide. The job was completed in an hour. Engineers then proceeded to their next tasks of blowing gaps in the sea wall behind the beach and clearing mine fields. Enemy opposition consisted only of intermittent shelling.
>
> While engineers worked on the beach, the 3d battalion, 8th Infantry, supported by tanks of the 70th Tank Battalion, and the 3d Battalion, 22d Infantry, were landing and moving out. Well before H plus 3 hours the beach area had been cleared and landings were virtually routine, harassed only by sporadic enemy fire.

*--304--*

------------------------------------------------------------------------

<span id="page305"></span>

> <span id="map3"></span>
>
> <a href="maps/USA-E-XChannel-3.jpg" target="mapwindow"><img src="maps/USA-E-XChannel-3m.jpg" /></a>  
> *Map 3*
>
> Early success and extraordinarily light casualties on UTAH Beach contrasted sharply with the difficulties experienced during those first critical three hours at OMAHA. The German *LXXXIV Corps* and *Seventh Army* believed through most of D Day that the OMAHA assault had been stopped at the water's edge. It was late in the morning before General Bradley aboard the *Augusta* could have contradicted that view and much longer before the Allied command could feel secure about the V Corps beachhead.<sup><a href="#fn64" id="cn64">64</a></sup>
>
> Leading the attack of General Gerow's V Corps was the 1st Division (Maj. Gen. Clarence R. Huebner) assaulting with two regiments abreast, the 116th Infantry (attached from the 29th Division) on the

*--305--*

------------------------------------------------------------------------

<span id="page306"></span><span id="page307"></span>

> <a href="img/USA-E-XChannel-51.jpg" target="mapwindow"><img src="icn/USA-E-XChannel-51.jpg" /></a>  
> AERIAL VIEW OF UTAH BEACH ON D-DAY MORNING.

*--306/307--*

------------------------------------------------------------------------

<span id="page308"></span>

> right, the 16th Infantry on the left.<sup><a href="#fn65" id="cn65">65</a></sup> Each regiment was to land two battalion landing teams at H Hour with initial missions to clear the beach defenses and seize and secure that portion of the beachhead maintenance line in their respective zones. (<a href="maps/USA-E-XChannel-XI.jpg" target="mapwindow"><em>Map XI</em></a>) The beachhead maintenance line roughly followed the ridge of high ground parallel to the main coastal road and was in most places from two to three miles inland. From this line the assault regiments, supported by the 18th Infantry landing after H plus 3 hours and the 26th Infantry landing on order of the Commanding General, V Corps, would punch out toward the D Day phase line. Occupation of that phase line would mean securing a coastal strip five or six miles deep astride the Bayeux highway.
>
> The 116th Infantry was responsible for capturing the Pointe du Hoe coastal battery. On the assumption that the six partially casemated 155-mm. guns would not have been destroyed by pre-D Day bombardment and the heavy naval fire directed on them just before H Hour, two Ranger battalions were attached to the 116th Infantry with the special H Hour mission of taking out the guns. Three companies of Rangers from the 2d Ranger Battalion were to land at the foot of the cliff which the fortified battery surmounted, scale the cliff by means of rope ladders, and attack the German positions. Another company, landing on the 116th Infantry main beaches to the east, would attack the fortifications at Pointe et Raz de la Percée and then continue westward to cover the flank of the Ranger force at Pointe du Hoe, provided the initial landings succeeded; otherwise they would come in on the 116th beaches and assist the right battalions of the 116th in attacking westward.
>
> The whole right flank of the V Corps assault forces would thus swing due west almost immediately on landing while the left battalion of the 116th and the 16th Infantry pushed south. It was hoped to clear the coast as far as Isigny by the end of D Day. It even seemed possible that Isigny itself might fall either to the 116th or to the 115th Infantry.<sup><a href="#fn66" id="cn66">66</a></sup> The latter regiment, landing on corps order, would initially leapfrog the 116th to organize the high ground around Longueville.
>
> Perhaps the most important job assigned to the first assault waves was the reduction of enemy positions defending the roads leading from the beach inland. The gently sloping sand of OMAHA Beach was backed by an embankment of loose stones, or shingle, in places of as much as fifteen yards wide. In the Vierville sector the

*--308--*

------------------------------------------------------------------------

<span id="page309"></span>

> shingle piled up against a part-masonry, part-wood sea wall. On the rest of the beach there was no wall, but the shingle lay against a sand embankment or dune line. Both the shingle and the dune line were impassable for vehicles. Behind the beach rose scrub-covered bluffs 100 to 170 feet high of varying steepness and merging east with the cliffs, which at Pointe et Raz de la Percée and east of Colleville marked the extremities of the 7,000-yard crescent beach. The bluffs were cut by five draws. Through four of these ran unimproved roads, one connecting with the main coastal highway at Vierville-sur-Mer, two at St. Laurent, and one at Colleville.<sup><a href="#fn67" id="cn67">67</a></sup> The fifth draw northeast of Colleville was steep and contained only a trail, but it was considered capable of development as a vehicle exit. The plan assumed these exits would be open to traffic at least by H plus 2 hours when the heavy flow of vehicular reinforcements was scheduled to begin. The importance of the beach exits was, of course, as obvious to the Germans as to the Allies and local coastal defenses were grouped to deny their use to the attackers.<sup><a href="#fn68" id="cn68">68</a></sup> On the other hand, the 1st Division had precise information on the location of these defenses and every provision was made to give the assaulting infantry the heavy fire support needed to knock them out. (<a href="maps/USA-E-XChannel-XII.jpg" target="mapwindow"><em>Map XII</em></a>)
>
> At H minus 50 minutes, two companies of DD tanks (741st Tank Battalion) destined for the 16th Infantry beaches were launched 6,000 yards offshore and almost immediately began to flounder. Of the thirty-two tanks launched only five reached shore.<sup><a href="#fn69" id="cn69">69</a></sup> These were the first of the casualties to the weather. There were others. The assaulting infantry was transferred from transports to LCVP's ten to eleven miles offshore. At least ten of the ferrying craft were swamped on the way in. More serious for the operation was the sinking of much of the artillery. The attempt to ferry guns ashore in DUKW's through the heavy seas proved disastrous. All but one of the 105-mm. howitzers of the 11th Field Artillery Battalion were

*--309--*

------------------------------------------------------------------------

<span id="page310"></span>

> <a href="img/USA-E-XChannel-52.jpg" target="mapwindow"><img src="icn/USA-E-XChannel-52.jpg" /></a>  
> AERIAL VIEW OF OMAHA BEACH ON D PLUS 1. *Note the five draws leading up from the beach.*

*--310/311--*

------------------------------------------------------------------------

<span id="page312"></span>

> <a href="img/USA-E-XChannel-53.jpg" target="mapwindow"><img src="icn/USA-E-XChannel-53.jpg" /></a>
>
> <a href="img/USA-E-XChannel-54.jpg" target="mapwindow"><img src="icn/USA-E-XChannel-54.jpg" /></a>
>
> <a href="img/USA-E-XChannel-55.jpg" target="mapwindow"><img src="icn/USA-E-XChannel-55.jpg" /></a>
>
> TERRAIN ON OMAHA BEACH. *Bluffs west of Vierville Draw (top). In distance is Pointe et Raz de la Percée. Concrete casemate in bluff is sited to cover beach. Hamel au Prétre (center) as seen from Vierville Draw. Les Moulins area (bottom) as seen from the east.*

*--312--*

------------------------------------------------------------------------

<span id="page313"></span>

> sunk. Six of the 105's belonging to the 7th Field Artillery Battalion suffered the same fate. Five of the six howitzers of the 16th Infantry Cannon Company were also swamped. In addition to these wholesale losses the 58th Armored Field Artillery Battalion, whose guns were mounted on LCT's and had taken part in the initial beach drenching, lost three of its pieces when the craft carrying them hit mines. In short, the artillery that was planned to support the infantry attack particularly in the advance inland did not reach the shore.
>
> The weather contributed also to navigational difficulties. Mist mixed with the smoke and dust raised by the naval bombardment obscured landmarks on the coast; in addition a lateral current of from two to three knots tended to carry craft eastward of their touchdown points. The actual errors in landing caused thereby were considerably less than at UTAH, in most cases amounting to not more than a few hundred yards. On the other hand, they proved much more serious for the tactical situation, partly because the errors were not constant, with the result that units became scattered on the final approach. Since the men had been briefed only for their particular areas, they were confused by the changed picture. The difficulties were compounded by the heavier enemy opposition which had the effect of isolating boat sections only a few hundred yards apart and at first made reassembly and reorganization for improvised missions almost impossible.
>
> Naval gunfire had temporarily neutralized some of the enemy batteries and fortifications but most of them were still able to fire at the incoming troops as soon as the bombardment was forced to lift inland. The 1st Division men in the first LCVP's could hear machine gun bullets splatter against the steel ramps of their craft before they grounded. Debarking in water sometimes up to their necks, the troops on some sectors of the beach were met with a hail of bullets that drove some to seek shelter under the surf, others to scramble over the sides of the craft. Control of boat sections was thus often lost before the men were even started in to the beach. The troops, overladen with heavy clothing and equipment, waded slowly through the surf and through fire that increased as they approached the beach. Some stopped to rest or seek shelter behind obstacles. Some lay at the water's edge and were able eventually to crawl in with the tide. But casualties generally were heavier among those who delayed in getting up onto the beach. Many of the wounded were drowned in the rising tide.
>
> The first wave should have landed nine companies evenly spaced along the beach. Because of withering enemy fire and mislandings, however, the right wing all but disintegrated; two companies bunched in front of les Moulins, and the remainder of the landings (elements of four companies) clustered in the Colleville sector. One company was carried so far to the east that it landed an hour and a half late.
>
> The two right-flank companies (Company C of the 2d Ranger Battalion, and Company A of the 116th Infantry) landed as scheduled in front of the Vierville draw. One craft foundered and one was hit four times by mortar fire. Men from the remaining craft struggled to shore. Intense small arms fire took toll of about two-thirds of Company A and more than half of the Ranger company before any reached the comparative shelter of the sea

*--313--*

------------------------------------------------------------------------

<span id="page314"></span>

> <a href="img/USA-E-XChannel-56.jpg" target="mapwindow"><img src="icn/USA-E-XChannel-56.jpg" /></a>
>
> ASSAULT LANDINGS, OMAHA BEACH. *LCVPs unloading infantry in the surf (above), and (below) men of the 1st Division, loaded with equipment, heading for the shore.*
>
> <a href="img/USA-E-XChannel-57.jpg" target="mapwindow"><img src="icn/USA-E-XChannel-57.jpg" /></a>

*--314--*

------------------------------------------------------------------------

<span id="page315" <p="">wall or the base of the cliff. Of the sixteen tanks scheduled to land in this sector just ahead of the infantry, only eight survived enemy artillery to reach the shore. All had been brought in on LCT's as 116th Infantry officers decided the sea was too rough to launch the DD's.</span>

In the eastern part of the 116th Infantry zone the initial landings had not gone much better. A 1,000-yard gap separated the troops who touched down there from the remnants of the two companies on the right. The two companies of tanks that landed first were brought in on LCT's without losses. This initial success was not shared by the infantry. Only two of the three companies of the 2d Battalion, 116th Infantry, landed within the regimental zone. One of these companies lost a quarter of its men to enemy fire during the forty-five minutes which it took them to cross the beach to the protection of the shingle bank. The remainder had better luck in landing in front and just west of les Moulins where the bluff was obscured by smoke fires and enemy fire was sporadic and inaccurate. Even these men were somewhat disorganized and the officers who survived with them were confused by the knowledge that they had landed east of their designated beaches.

The experience of the 16th Infantry on the left flank of the division duplicated that of the 116th, as scattered landings and heavy casualties left the first boat sections incapable of undertaking their primary assault missions. In the 16th's zone, however, one soft spot was discovered. Four boat sections of the 2d Battalion, 16th Infantry, landing between the St. Laurent and Colleville exits, crossed the beach with only two casualties from enemy fire. The local defense of this sector of the beach was the Colleville strong point, which was planned as three mutually supporting resistance nests. Of these the field fortified position atop the bluff midway between the two draws was unoccupied in February 1944 and seemingly remained unoccupied on D Day.<sup><a href="#fn70" id="cn70">70</a></sup> Apparent German negligence that left the beach northwest of Colleville without immediate defense was balanced at first by Allied ill fortune in landing so few men there. Except for those four boat sections of the 2d Battalion the first wave of the 1 6th Infantry (Companies E and F) touched down immediately in front, or east, of the occupied fortifications of the Colleville strong point and was there caught in machine gun fire as intense as that which decimated the 116th Infantry. Many of the men of Company E, hard hit and exhausted in their efforts to wade ashore, flopped on the sand and crawled in ahead of the tide; nearly half of them did not survive. Because of the swamping of most of the DD tanks and immediate enemy destruction of five of the company of mediums beached from LCT's, the 16th Infantry had initially only a third of the planned armor support. Those tanks available went into action on the beach between the St. Laurent and Colleville exits.

The heavy losses and disorganization of the first wave had repercussions on each succeeding wave through the morning of D Day. The first serious effect of the failure to neutralize enemy beach defenses was the inability of the 6th Special Engineer Brigade and naval demolition parties to blow gaps in the beach obstacles as

*--315--*

------------------------------------------------------------------------

<span id="page316"></span>

> <a href="img/USA-E-XChannel-58.jpg" target="mapwindow"><img src="icn/USA-E-XChannel-58.jpg" /></a>
>
> FIRST AID ON THE BEACH. *Soldiers of the 16th Infantry (above) being treated for injuries, and wounded soldier (below) receiving plasma.*
>
> <a href="img/USA-E-XChannel-59.jpg" target="mapwindow"><img src="icn/USA-E-XChannel-59.jpg" /></a>

*--316--*

------------------------------------------------------------------------

<span id="page317"></span>

> planned. Weather conditions also played a hand in hindering the engineers from accomplishing their mission. Half the demolition teams were delayed in landing and only a third of them touched down on their appointed sectors. Since the rest were carried eastward by the coastal current, the 116th Infantry zone received substantially less than the scheduled effort. But enemy fire also took a heavy toll of both men and equipment. Of sixteen bulldozers only three could be put into operation on the beach, and one of these was prevented from maneuvering freely by riflemen who sheltered behind it. So many of the marking buoys and poles were lost that only one of the six gaps blown by 0700 could be marked. Casualties to the engineers amounted to about 40 percent for the day and were certainly very much higher for the first groups ashore. In half an hour after H Hour the tide, rising at the rate of about four feet an hour, had covered the obstacles to an extent that made further clearance impossible;<sup><a href="#fn71" id="cn71">71</a></sup> remnants of the engineers joined the infantry behind the shingle to wait for the next tide. Fifteen officers and men of the demolition parties from private to colonel were awarded the Distinguished Service Cross for carrying out their missions under incredible difficulties: a colonel had his craft come close to shore and directed it under heavy fire up and down along the beach so that he could observe what had to be done, then came ashore, issued new orders to expedite the clearance, and supervised the work under fire; a lieutenant, though wounded in the legs while coming ashore, refused evacuation, directed his team in demolishing the obstacles until the tide covered them, and returned to the job when the tide permitted and was again wounded; an enlisted man operated a tankdozer until it was knocked out of action and then crossed the fire-swept beach to mount a deserted bulldozer and continue his job.<sup><a href="#fn72" id="cn72">72</a></sup>
>
> The second group of assault waves, consisting of five separately timed landings, was to complete the build-up of the two assault regiments by H plus 1 hour and bring in the 81st Chemical Battalion, two combat engineer battalions whose principal task would be to clear mine fields for the advance inland, naval shore fire control parties, and advance elements of artillery, medical, and antiaircraft units. In the zone of the 116th Infantry, the remaining three companies of the 1st Battalion were to come in behind Company A on the right. On the left the heavy weapons company of the 2d Battalion would land to complete that unit and would be followed by the 3d Battalion.
>
> The right flank, however, continued to be an area of particular misfortune. Only scattered sections of the reinforcing units managed to land there and they were hit by the same destructive fire that had virtually knocked Company A out of the battle. The battalion headquarters company, including the beachmaster for the 1st Battalion sector, landed at the base of the cliff west of the rifle companies and under such severe enemy small arms fire that it was unable to move most of the day. The heavy weapons company, scattered and hard hit on the approach, took two hours to assemble survivors. It salvaged only three mortars, three machine guns,

*--317--*

------------------------------------------------------------------------

<span id="page318"></span>

> and a few rounds of ammunition. Only one company of the 1st Battalion survived as an organized group capable of pursuing its assault missions. This was Company C, which mislanded 1,000 yards east of its planned beach within the area of the bluffs covered by the smoke of a brush fire. With few casualties and equipment virtually intact, the company waded in on a front of not more than a hundred yards and reorganized in the shelter of the sea wall.
>
> Next to land in the 116th zone were the Rangers. The 5th Ranger Battalion together with two companies of the 2d Rangers had waited offshore for news of the assault on Pointe du Hoe, which would determine whether they landed there or came in on the 116th Infantry zone. The Pointe du Hoe assault, however, had been delayed forty minutes by the eastward drifting of the craft carrying the Rangers. There was therefore no news at all, and the Ranger reinforcements, concluding that the assault must have failed, proceeded with the alternative plan. The 5th Ranger Battalion followed Company C, 116th Infantry, and shared the relatively easy assault in landing too far east. But the two companies of the 2d Ranger Battalion came in about where planned on the fire-swept right flank behind elements of Companies A and B. Only between a third and a half of the two 65-man companies survived to take shelter at the head of the beach.
>
> In the 2d Battalion zone, the second wave brought in the heavy weapons company and battalion headquarters. Company H suffered such losses and disorganization that it could be of little immediate help in supplying mortar or machine gun support. The battalion commander, Maj. Sidney V. Bingham, Jr., coming ashore near les Moulins, organized a few sections of Company F which had landed in the first wave and attempted an assault on the enemy positions in the draw.<sup><a href="#fn73" id="cn73">73</a></sup> The attempt made with only a handful of men was unsuccessful, but in the meantime the 3d Battalion was landing bunched up astride the regimental boundary just east of les Moulins. It was somewhat disorganized by the intermingling of units but suffered little from enemy fire in crossing the beach.
>
> At the end of the first hour the 116th Infantry had at least a nucleus of force which could be organized for attack against the enemy's beach positions. Most hopeful was the situation roughly in the center of the regimental zone just west of les Moulins where enemy fire masked by smoke was light and ineffective, and where shortly after 0730, by great good fortune, the regimental command group with Col. Charles D. W. Canham and Brig. Gen. Norman D. Cota, the assistant division commander, came ashore.
>
> The experience of the 16th Infantry's later waves was similar to that of the 116th. Losses were lighter but the confusion and intermingling of units on the beaches became more serious. The two remaining companies (G and H) of the 2d Battalion followed by the 1st Battalion landed about where planned, due north of Colleville. The 3d Battalion completed landing on the left shortly after 0800. The 3d Battalion headquarters, however, landed to the west and could not join its troops for several hours. The 16th Infantry suffered another misfortune when the regimental executive officer, coming in with the first

*--318--*

------------------------------------------------------------------------

<span id="page319"></span>

> section of the headquarters, was killed together with thirty-five of his men. The commander, Col. George A. Taylor, did not arrive until 0815 with the second headquarters section.
>
> Command was generally one of the gravest problems faced by assault units, not only because officer casualties were high and mislanding of command groups had left many units leaderless, but also because of extreme difficulties of communication. Three-quarters of the 116th Infantry's radios were destroyed or useless.<sup><a href="#fn74" id="cn74">74</a></sup> Furthermore, in the confusion of the mixed units, which were under heavy fire in some places, their men huddled along the shingle embankment or sea wall and generally shaken by the shock of the first few minutes of severe action, it would have been impossible for any commander to exercise control over more than a small group of men on a relatively narrow sector of the front.
>
> In these first few hours on OMAHA Beach, the OVERLORD operation faced its gravest crisis. Deprived of the expected air support by accident of weather and preceded by a generally ineffective beach drenching, the 1st Division had gone in against the one sector of the Normandy coast that had anything like the kind of cordon defense which Field Marshal Rommel counted on to hold and smash the Allies on the beaches. Instead of attacking in the sector of one regiment of an overextended static division as expected, General Huebner's troops hit on the front of a full attack infantry division, the *352d,* whose presence in the coastal zone had been missed by Allied intelligence even though it had been in place for almost three months.<sup><a href="#fn75" id="cn75">75</a></sup>
>
> To the German officer in command of the fortifications at Pointe et Raz de la Percée it looked in these first hours as though the invasion had been stopped on the beaches. He noted that the Americans were lying on the shore seeking cover behind

*--319--*

------------------------------------------------------------------------

<span id="page320"></span>

> the obstacles, that ten tanks and a "great many other vehicles" were burning. The fire of his own positions and the artillery, he thought, had been excellent, causing heavy losses. He could see the wounded and dead lying on the sand.<sup><a href="#fn76" id="cn76">76</a></sup>
>
> Sketchy reports to V Corps and First Army must have painted very much the same picture for the American command. From a DUKW cruising 500 to 1,000 yards offshore, Col. Benjamin B. Talley, the assistant chief of staff of V Corps, radioed General Gerow what he could observe of the progress of the landings. Observation was difficult, and on the whole Colonel Talley refrained from reporting mere pessimism. However, he had to report something of the evident disorganization. He could see that the beaches were jammed with infantrymen and that enemy artillery and machine gun fire was still effective. He sent a message to that effect about 0930. What particularly concerned him was the fact that reinforcing waves were being held up by the continued enemy opposition and the LCT's were milling around offshore like "a stampeded herd of cattle," although some of the more daring commanders took their craft into the hail of enemy fire and beached them. This situation seemed to Talley to continue without alleviation until midmorning, and it was the situation conveyed to Generals Gerow and Bradley.<sup><a href="#fn77" id="cn77">77</a></sup>
>
> Already, however, as Talley sent forward his discouraging reports, the crisis was bit by bit dissolving. Among the groups of scared, tired riflemen huddled along the beach were a few intrepid leaders--officers, noncoms, and privates on whose individual backs the big responsibility at the moment lay. They began by example and exhortation to prod the men to get up, leave such poor shelter as they had found, and walk or crawl across the beach flat and up the hills where the enemy was dug in with rifles, mortars, and machine guns. From the larger perspective the combined weight of Allied arms was gradually wearing down the defenders. The *916th Regiment* in the center of the *352d Division* sector, while reporting that the landings had been frustrated, added that its own casualties were mounting chiefly from the heavy Allied naval fire and that consequently reinforcements were needed. Reinforcements, however, could not immediately be spared since they were much more urgently needed elsewhere.
>
> The gravest immediate threat for the Germans arose to the east of V Corps where the British assault cracked through the coast defenses in some places during the first few hours. (<a href="maps/USA-E-XChannel-XIII.jpg" target="mapwindow"><em>Map XIII</em></a>) The British Second Army attacked with three divisions abreast under control of I and 30 Corps. Immediately on the flank of the American attack, the British 50th Division landed two infantry brigades supported by tanks of the 8th Armoured Brigade and assault teams of the 79th Armoured Division and the 47th Royal Marine Commando. The troops touched down approximately on time at 0725.
>
> Opposition was heavy at certain points, but on the whole it was much less determined

*--320--*

------------------------------------------------------------------------

<span id="page321"></span>

> than at OMAHA. In the 50th Division zone le Hamel, strongly defended by the *1st Battalion,* *916th Regiment,* resisted until late in the day. To the east, however, the British division's left brigade struck a soft spot in the German defenses. The strong point at la Riviere held out only a few hours and when it fell at about 1000 its defenders, the *441st Ost Battalion,* attached to the *716th Division,* broke and pulled out, leaving the road to Bayeux open. This development, however, was not known to the British. Opposition continued to be reported south of Buhot, at Ryes, St. Sulpice, and Summervieu. It was always difficult in the early stages of the assault properly to distinguish enemy delaying action from major opposition or to discover where the holes were in the German defense. The 50th Division, moreover, still had only its assault forces ashore. Rising tide had prevented effective clearance of underwater obstacles. Enemy opposition and mines delayed the opening of beach exits. Caught in the resulting congestion, the two follow-up brigades of the 50th Division were two hours late in landing. When they did arrive, they found their assembly areas still not entirely cleared of enemy. Elements of the *352d Division,* in fact, were still on the Meuvaines ridge after midday.<sup><a href="#fn78" id="cn78">78</a></sup>
>
> From the German point of view the crumbling of the *441st Ost Battalion* was immediately critical. The gap had to be plugged at once. The *915th Regiment* reinforced (*LXXXIV Corps* reserve) had been stationed near Bayeux and had often practiced just the maneuver now required--counterthrust, toward Crépon. But earlier in the morning (at 0400) the *915th* had been ordered to the Carentan- Isigny area to attack reported large-scale enemy airborne landings between the Vire and Douve Rivers. The report was discovered to be unfounded at just about the time the hole in the *716th Division* opened up. Threatened with having his whole right flank rolled up, Generalleutnant Dietrich Kraiss, the commanding general of the *352d Division,* secured corps approval for the return of the *915th Regiment.* But an hour was consumed trying to reach the regiment. Then it had to countermarch almost twenty miles from a point nearly five miles west of the Forêt de Cerisy. The march was made partly on foot, partly by bicycle and French motor vehicles which suffered numerous mechanical breakdowns. Another three hours passed before even a portion of the unit was in position to attack. That delay proved crucial, for in those hours much happened to change the situation on OMAHA completely.<sup><a href="#fn79" id="cn79">79</a></sup>
>
> ### *The D-Day Beachhead*
>
> First Army's assault plans provided that the initial task of clearing the beaches be carried out by assault sections organized by boatloads. Troops were then to proceed inland to various assembly areas where they would be reorganized in battalions and regiments to carry out their subsequent D-Day missions of securing and consolidating the corps beachheads.
>
> On OMAHA Beach the troops of V Corps in order to reach their assembly areas had to cross a beach flat, varying in width from a few yards at each end to about 200 yards in the center, and climb steep bluffs

*--321--*

------------------------------------------------------------------------

<span id="page322"></span>

> behind. (*See <a href="maps/USA-E-XChannel-XII.jpg" target="mapwindow">Map XII</a>.*) Although the beach flat offered only patches of tall marsh grass for concealment, the bluffs had irregularities that could provide cover for individual riflemen. The plan called for clearing five exit roads from the beach and an advance inland generally along the axis of these roads. But despite naval bombardment and tank fire from the beach on enemy positions defending these roads all remained active during the first two hours of the assault. Movement off the beach, in consequence, at first took place between the exits. It began before 0800 in a number of independent actions by groups of men, never more than of company size and often much smaller. Some of the attacks had tank fire support; others were materially aided by the bold action of destroyers which came within a few hundred yards of the beach and delivered direct fire wherever they could observe enemy activity.<sup><a href="#fn80" id="cn80">80</a></sup>
>
> Certainly the first troops to move inland were the Ranger companies at Pointe du Hoe, though their action was independent of the main landings at OMAHA and was, in fact, part of the fire support plan rather than of the assault proper. Forty minutes late, the three companies of the 2d Ranger Battalion under command of Lt. Col. James E. Rudder<sup><a href="#fn81" id="cn81">81</a></sup> made landfall under close-in supporting fire of the U.S. destroyer *Satterlee* and the British destroyer *Talybont.* The *Satterlee,* having delivered effective preliminary fire, stayed in the area near shore and watched over the Ranger action most of the day. By 1730 it had expended 70 percent of its ammunition in missions in aid of the Rangers and was relieved by the *Barton* and *Thompson.* The *Satterlee's* fire was particularly effective during the first moments of the assault when it forced the enemy to take cover while the Rangers scaled the cliff with ropes and ladders.<sup><a href="#fn82" id="cn82">82</a></sup> Enemy fire, reduced by the naval shellings, remained light after the Rangers reached the top of the cliff and began moving inland in groups of three or four across a desert cratered by concentrated aerial and naval bombardment. In disparate and confused actions the Rangers speedily carried out their primary mission. Patrols found the 155-mm. gun emplacements deserted. The guns themselves were discovered farther inland in a camouflaged field position. They were, curiously enough, unmanned and unguarded. The handful of Rangers who stumbled on them were therefore able to destroy them easily. Thus far the Rangers, despite thirty to forty casualties in the landings, had not had a hard fight. Their difficulties began later in the day with the first of a series of counterattacks by the *1st Battalion,* *914th Regiment,* that would keep them in a state of siege for two days, and reduce their combat effectives to about ninety.<sup><a href="#fn83" id="cn83">83</a></sup>

*--322--*

------------------------------------------------------------------------

<span id="page323"></span>

> <a href="img/USA-E-XChannel-60.jpg" target="mapwindow"><img src="icn/USA-E-XChannel-60.jpg" /></a>  
> RANGERS SCALING THE CLIFFS AT POINTE DU HOE

*--323--*

------------------------------------------------------------------------

<span id="page324"></span>

> Apart from the Ranger movements at Pointe du Hoe, the principal areas of penetration inland were four, two in each regimental zone. The 116th Infantry with the 5th Ranger Battalion made successful independent attacks inland on both sides of the les Moulins draw. On the west side Company C, urged on by Colonel Canham and General Cota, left the protection of the sea wall and, after blowing a gap in the concertina wire along the beach road, crossed the 150 yards of beach flat to the bluffs.<sup><a href="#fn84" id="cn84">84</a></sup> Men were lost to machine gun fire in this initial attack but, once they gained the hillside, smoke concealed their moves and small folds in the ground gave them good protection from enemy bullets. They found no Germans atop the bluff and proceeded a couple of hundred yards inland before fire from the flanks caused them to halt. Company C was closely followed by the 5th Ranger Battalion which sent its men forward by platoons as they landed. The command group of General Cota was established shortly after 0830 near the crest of the hill and began the task of reorganizing disordered units.
>
> At approximately the same time the 3d Battalion, 116th Infantry, in a series of simultaneous, independent advances by straggling columns of twenty to thirty men, left the beaches east of les Moulins and arrived by various routes on the high ground. Meeting no resistance on the crest, the sections, coagulating haphazardly into larger groups, began moving southwest generally toward St. Laurent and their designated assembly area beyond.
>
> Penetrations in the 16th Infantry zone were made between the St. Laurent and Colleville exits and up the draw. on the extreme eastern flank of the beach. The former breach was opened up by two companies of the 2d Battalion, 16th Infantry. Company G and a section of Company E made separate attacks at about the same time and only a few yards apart. After blowing gaps through the wire beyond the shingle embankment the two groups crossed the flats and converged on the lower slopes of the bluff. But despite some effort to coordinate the advance the "companies" continued independently, threading their way through mine fields that took some casualties and slowed the advance. Company G, covered by the fire of their 60-mm. mortars and light machine guns emplaced on the beach, gained the top of the bluff against only light enemy opposition and pushed inland. Company E (consisting of twenty-three men under 2d Lt. John M. Spalding) on reaching the top of the hill turned west and attacked the rear of the enemy fortifications defending the east side of the St. Laurent exit. It was a typical coastal position including pillboxes and a maze of communicating trenches. The garrison, men of the *916th Regiment,* caught by surprise and demoralized by naval fire hitting just below the top of the bluff, fought a confused battle for about two hours before an officer was cornered and forced with a group of about twenty men to surrender. Although Lieutenant Spalding had too few men to mop up the area, his action was the first step in clearing a vehicle exit from the beach. In the meantime most of the 2d and 1st Battalions of the 16th Infantry had followed Company G's route up the bluffs, on order of Colonel

*--324--*

------------------------------------------------------------------------

<span id="page325"></span>

> Taylor, regimental commander, who on his arrival on the beach at 0815 had begun organizing his men and pushing them forward.
>
> The 3d Battalion, 16th Infantry, at the same time had opened its own path inland at the draw northeast of Colleville. Under covering fire from tanks on the beach and naval guns, 3d Battalion units made a direct attack on the enemy strong point defending this draw and by 0900 had, with surprisingly small losses, succeeded in subduing it.<sup><a href="#fn85" id="cn85">85</a></sup>
>
> Improvisation and courageous personal leadership in the first hours had taken considerable numbers of troops off the beach where for a time it had looked as though they might be stopped. However, the initial successes were limited by the fact that the infantry had very few heavy weapons, no supporting artillery, and, since the beach exits had not been cleared, little prospect of getting tank support or large-scale supplies or reinforcements. The beaches themselves remained under heavy enemy fire and on most sectors no gaps had been blown through the obstacles. The obstacles submerged by the rising tide materially increased the difficulties of approaching the beach. Landing craft became more and more congested offshore. When shortly after 1000 the 18th Infantry began landing in column of battalions in the 16th Infantry zone, it must have looked to them as though little progress of any kind had been made in the assault. The enemy apparently still had control of the high ground above the beach; American troops still seemed pinned behind the shingle embankment and vehicles were piled up along the narrow strip of beach.
>
> In breaking this deadlock during the next hour, naval intervention played an important part. At about 1030 two landing craft, LCT 30 and LCI(L) 44, steamed full ahead through the obstacles off the Colleville beaches, firing all weapons at enemy strong points guarding the Colleville draw. The craft continued to fire after beaching. Not only did their action prove that the obstacles could be breached by ramming, but their fire, though failing to neutralize German positions in the Colleville draw, had at least a heartening effect on the assault troops. At about the same time two destroyers approached to within 1,000 yards of the beach and shelled enemy positions from les Moulins eastward. Under cover of this fire engineers of the 37th and 146th Engineer Combat Battalions<sup><a href="#fn86" id="cn86">86</a></sup> bulldozed two gaps through the dune line on either side of the St. Laurent exit, filled the antitank ditch, and cleared the mine fields. The resistance east of this draw had already been neutralized by the 16th Infantry. While the engineers worked, heavy weapons of the 3d Battalion, 116th Infantry, contained other enemy defenses still in action. A pillbox west of the draw was reduced by skillfully directed destroyer fire at about 1130. The Germans in this last organized defense at the St. Laurent draw surrendered to the 2d Battalion of the 18th Infantry, which had begun landing at about 1000. Thus, in little over an hour, concerted bold action had wrought the most substantial improvement on the beach since H Hour. Reinforcements were coming ashore, and most

*--325--*

------------------------------------------------------------------------

<span id="page326"></span>

> important of all a road was at last open to move vehicles inland.
>
> In the meantime the battles inland were already being joined. The troops who gained the top of the bluffs by midmorning were scattered groups, a small percentage of the assault battalions, who were incapable of carrying out the D-Day advances as planned. Their objectives at first were simply to reach the various battalion assembly areas. Because of their small numbers and the difficulty of control in the hedgerow country their actions were fragmented, and because they completely lacked both armored and artillery support their movements could be, and constantly were, checked by small enemy prepared positions seldom held in even as much as company strength.
>
> Under the circumstances, this scattered resistance by small enemy groups constituted in sum a considerable obstacle to American advance. Furthermore, sporadic and uncoordinated as it seemed, it was in general the kind, though not quite the scale, of defense that the Germans had planned. Determined resistance in coastal positions, even though isolated or bypassed, did succeed at first in splintering the attacking forces so that only weak, disorganized elements could penetrate the hinterland. Continued, though relatively feeble, nodal defense inland during the day had the further effect of hindering reorganization and coordinated American action. So far the theory of coastal defense seemed justified in practice. That nothing came of this initial success was due, first, to the Germans' lack of reserves with which to counterattack the relatively weak penetrations, and, second, to the fact that, while the American ground attack had locally and temporarily been splintered, the vast supporting naval and air power was practically unopposed. By dominating the battlefield, planes and naval guns smashed such German reserves as could be gathered for a counterthrust and so gave the fragmented V Corps infantry a chance to recover, rebuild, and again become a ground army superior in numbers and equipment to anything that the Germans could thereafter muster to meet them.
>
> Action during the remainder of D Day inland from OMAHA Beach took place in three general areas, Vierville-sur-Mer, St. Laurent, and Colleville. The three actions were generally unconnected and uncoordinated.
>
> Attacks on Vierville-sur-Mer were made by elements of the 1st and 2d Battalions of the 116th Infantry and the 5th Ranger Battalion--something more than 600 men altogether. These units were reorganized near the edge of the bluff and started inland between 1000 and 1100. The plan was for the Rangers to bypass the town and attack from the south while the 116th advanced along the exit road. The Rangers reached the coastal highway but found further advance across the fields checked by enemy machine gun positions concealed among the hedgerows. After four hours of trying in vain to get around the enemy guns, they turned and entered Vierville in the early afternoon. The town had already been captured by the 116th, which met little opposition in its frontal attack. At 1100 Vierville was clear, and Colonel Canham then tried to push the attack westward to make juncture with the Ranger force at Pointe du Hoe. His men, however, encountered the same kind of nettling opposition that had stopped the Rangers. Lacking heavy weapons to

*--326--*

------------------------------------------------------------------------

<span id="page327"></span>

> support the attack, Colonel Canham decided to call it off and return to the defense of Vierville. He had few men to spare from that task since few reinforcements had landed in the area and the beach exit was not opened until evening. Although enemy beach defenses opposite Vierville had been largely neutralized by naval fire early in the afternoon, the engineers responsible for clearing the exit had scattered in the landing, losing three-quarters of their equipment and many of their men.
>
> East of the les Moulins draw, the 3d Battalion, 116th Infantry, and scattered sections of the 2d Battalion fought inland toward St. Laurent and the 3d Battalion assembly area southwest. During the day confused and inconclusive fighting by small groups of men took place in country which, though relatively open, still provided the enemy with sufficient cover that the American troops could seldom locate their positions. The 116th Infantry was stopped short of St. Laurent.
>
> In the meantime northeast of the town another attack, by the 115th Infantry, was in progress. The 115th had been brought ashore ahead of schedule. Original plans had called for the rifle and heavy weapons companies of this regiment to be held as V Corps floating reserve to be employed on order of General Gerow. If all went according to plan in the initial assault, the 115th Infantry would be committed in the zone of the 116th to organize the high ground near Longueville and be prepared to capture Isigny. Alternative plans were made to have the 115th take over missions of the 116th in case any units of the latter regiment should fail in the assault.<sup><a href="#fn87" id="cn87">87</a></sup> Initially the 115th Infantry was to be on call between the first and second tides. But Maj. Gen. Charles H. Gerhardt, commanding the 29th Division, contended that this plan meant leaving the 116th Infantry without reinforcements for a dangerously long time.<sup><a href="#fn88" id="cn88">88</a></sup> At the last minute, therefore, General Gerow decided to commit the 115th Infantry immediately in support of the 116th. At H Hour Admiral Hall on General Gerow's request gave the order to land the 115th beginning at H plus 4 hours.
>
> Like so many units, the 115th Infantry drifted eastward, and instead of coming in where scheduled on the beaches in the left portion of the 116th zone it landed on top of the 18th Infantry east of St. Laurent. The confusion on the crowded beaches and intermingling of 18th and 115th units delayed the movement inland of both regiments. It was early afternoon when, under orders to carry out the primary mission in the Longueville area, the battalions of the 115th Infantry started for their assembly areas southwest of St. Laurent. The 2d Battalion attacked St. Laurent, estimated to be held by about a company of Germans, but could make no headway. At dusk the attack was halted and the battalion withdrawn to join the 1st, which had bypassed St. Laurent to the east and moved a few hundred yards south of the town. The 3d Battalion, on the regiment's left flank, had in the

*--327--*

------------------------------------------------------------------------

<span id="page328"></span>

> meantime made even slower progress and drew up at dark still north of the St. Laurent-Colleville road.
>
> Between St. Laurent and Colleville a whole series of confused and generally uncoordinated actions were taking place during the remainder of D Day as parts of two battalions of the 16th Infantry, supported during the afternoon by the 18th Infantry, attempted to maneuver south to positions along the beachhead maintenance line. Company G, the first unit to move inland in this area, at first made rapid progress, but an attack against Colleville drew an enemy counterattack that put the company on the defensive for the rest of the day. Elements of the 1st Battalion fought separate actions in the same general area attempting to clean up isolated enemy riflemen and machine gun positions.
>
> As the 18th Infantry landed, Brig. Gen. Willard G. Wyman, the assistant division commander and senior army commander ashore, had diverted all three battalions to take over the missions of the 16th Infantry. The 2d Battalion, going to the assistance of the 2d Battalion, 16th Infantry, at Colleville, passed to the west of Company G and at dark halted just south and southeast of the town. The 3d Battalion, at first ordered to capture Formigny and Surrain, was held up so long by small arms harassing fire that its orders were changed and it was sent to the high ground south of the highway to tie in with 16th Infantry on the left and the 115th on the right. The 1st Battalion was directed into the same general area with orders to attack Surrain, but at dark was still north of the St. Laurent-Colleville road.<sup><a href="#fn89" id="cn89">89</a></sup>
>
> The St. Laurent-Colleville sector was still considered weak. When the 26th Infantry, the first of the follow-up forces, landed in the evening, two battalions were ordered to take defensive positions southeast of St. Laurent ready to attack toward Formigny. The remaining battalion backed up the left flank where the 3d Battalion, 16th Infantry, with about one hundred men had managed to occupy le Grand Hameau. To help hold the position during the night seventeen tanks were moved up from the beach.
>
> While V Corps units struggled to find secure defenses for the night in their shallow lodgment VII Corps was pouring ashore almost unhindered. (*See <a href="maps/USA-E-XChannel-3.jpg" target="mapwindow">Map 3</a>.*) As the 8th Infantry battalions moved inland to their objectives they had only minor engagements with an enemy who, on the whole, showed little inclination to fight. The 3d Battalion was held up briefly north of Ste. Marie-du-Mont where it overran another of the batteries of the German *191st Artillery Regiment*--the unit which earlier in the day had caused the 506th Parachute Infantry so much trouble. The battalion then went on to the les Forges crossroads where it bivouacked for the night and where it was joined in the evening by the 2d Battalion. The 1st Battalion had moved almost due west from the beaches and reached Turqueville by nightfall.
>
> The 8th Infantry, when it halted for the night, was confronted by an enemy salient which cut the Valognes-Carentan highway between Ste. Mère-Eglise and les Forges, extending northeast as far as Turqueville. It was enemy from this salient that had attacked Ste. Mère-Eglise during the morning. The 505th Parachute

*--328--*

------------------------------------------------------------------------

<span id="page329"></span>

> Infantry counterattack had caused only a slight enemy withdrawal southward. The Germans were able thereafter to consolidate on high ground at Fauville where they formed a strong barrier between the 8th Infantry and the 82d Airborne Division.
>
> Late in the afternoon a task force of infantry and tanks, belonging to the 82d Airborne Division and under command of Col. Edson D. Raff, landed by sea with the mission of reinforcing their division in the Ste. Mère-Eglise area. Raff's men, including ninety men of the 325th Glider Infantry and a company of tanks of the 746th Tank Battalion, followed the 3d Battalion, 8th Infantry, into the les Forges position. The infantry battalion had already decided not to attack northward that evening. Raff, however, was concerned not only with getting his tanks through to his division, but also with clearing the area north of les Forges. The meadows in this area were the division's glider landing zone. Here at dusk artillery units were to land. Raff's tanks and infantry made several jabs at the enemy to try to discover his dispositions but, after three tanks were lost to enemy high-velocity fire, the attempt to get through was abandoned. The enemy remained at full strength and still well concealed when, on schedule at 2100, about sixty gliders came in low over the area and cut loose for landings. The Germans reacted with intense automatic fire. Many of the gliders crashed, others came down within the enemy lines. Casualties were heavy. Remnants of the glider force including the pilots were collected by Colonel Raff and formed into a makeshift defense for the night. In the northern portion of the 4th Division zone neither the 12th nor the 22d Infantry Regiment reached its D-Day objective. Delays were caused not by enemy opposition but by the difficulties of moving up through the marshes. The 22d was halted in the general area from Hamel de Cruttes on the coast to St. Germain-de-Varreville. The 12th came up on the left of the 502d Parachute Infantry, which was holding the 101st Division north flank near Beuzeville-au-Plain.
>
> General Bradley's right corps on UTAH Beach had its weaknesses at the end of D Day, but on the whole it was in a sound position, smaller than planned but better organized and stronger than might have been expected. The beach, though still under intermittent enemy artillery fire, was cleared and prepared for the orderly reception of reinforcements. The 4th Division was present in the beachhead virtually intact, organized and equipped for offensive action. Its casualties for the day were less than 200. If the position of the 82d Airborne Division caused some concern, the force was at hand to consolidate it.
>
> The situation on the left at OMAHA was quite different. The main V Corps position at the end of the day was the narrow sector between St. Laurent and Colleville, a toehold on the enemy shore nowhere more than a mile and a half deep. The right flank at Vierville-sur-Mer, held by elements of the 116th Infantry and the Rangers, was isolated from the main body although the beach exit was open and reinforcements thus could be brought in. All units were lacking vehicles, supplies, ammunition, artillery, and armored support necessary for further advance inland.
>
> No artillery could be landed during the morning. The elements of five battalions

*--329--*

------------------------------------------------------------------------

<span id="page330"></span>

> which beached in the afternoon all suffered heavy losses of equipment, including a total of twenty-six guns. Two antiaircraft gun battalions scheduled to arrive on D Day could not come in until the following day. Only one artillery mission was fired on 6 June. The V Corps losses for the day were about 2,000 killed, wounded, and missing.<sup><a href="#fn90" id="cn90">90</a></sup>
>
> The failure of the Germans to exploit the weakness of V Corps was the result quite simply of their own greater weakness. During the first few hours it looked as though the OMAHA assault had been stopped, and the chief concern of the *352d Division* was with its right flank which was threatened by the British penetration near Meuvaines. (*See <a href="maps/USA-E-XChannel-XIII.jpg" target="mapwindow">Map XIII</a>.*) To meet this the *LXXXIV Corps* reserve, the reinforced *915th Regiment* (*Kampfgruppe Meyer*) had been ordered to attack in the direction of Crépon. By 1100 the division commander, General Kraiss, began to consider the situation in his center more serious in the light of additional information on the whole invasion front. The *709th Division* opposing U.S. VII Corps was reporting strong armored reinforcements landed from the sea. At the same time the British were building up their beachhead. A concentration of shipping observed off St. Laurent was thought to indicate Allied intention to reinforce what had heretofore been considered minor penetrations in the St. Laurent area.<sup><a href="#fn91" id="cn91">91</a></sup> General Kraiss concluded (apparently for the first time) that the Allies were planning a two-pronged attack on Bayeux from bridgeheads at St. Laurent and Meuvaines. The *2d Battalion* of the *915th Regiment* was therefore split off from the force on its way toward Crépon and together with one antitank company (with twelve self-propelled 75-mm. antitank guns) was attached to the *916th Regiment* in the center of the division sector. The infantry reinforcements moved into the Colleville area in the early afternoon but reported that their counterattack had been stopped by firm American resistance and that they had suffered heavy losses.
>
> The body of *Kampfgruppe Meyer*<sup><a href="#fn92" id="cn92">92</a></sup> in the meantime advanced toward the area Bazenville--Villiers-le-Sec whence it planned to attack to Crépon. By the time it reached its assembly area at about 1730 it found the British already in possession. The units on the right were able to withdraw

*--330--*

------------------------------------------------------------------------

<span id="page331"></span>

> <a href="img/USA-E-XChannel-61.jpg" target="mapwindow"><img src="icn/USA-E-XChannel-61.jpg" /></a>  
> NINTH AIR FORCE B-26 OVER BRITISH BEACHHEAD *at Lion-sur-Mer. Note markings on plane. All Allied aircraft, except 4-engine bombers, in support of the invasion were painted thus for purposes of identification. Two black and three white stripes were painted on wings and around the fuselages.*
>
> to St. Gabriel where they were joined by the ten assault guns of the Kampfgruppe. But the infantry battalion under direct command of Colonel Meyer on the left brushed with British forces near Bazenville. Meyer was killed and the battalion lost contact with other German units for several hours. It seems clear that Meyer's forces made no concerted attack, but were chewed up in small defensive actions. The assault guns scored the only success of the day in knocking out four British tanks near Brecy. On the other hand four of the guns were themselves lost, possibly to British naval fire. Out of the entire Kampfgruppe only about ninety men escaped. In the evening these remnants were attached to the *726th Regiment,* which was ordered to establish a defensive line: Coulombs--St. Gabriel--the Seulles River west to Esquay-sur-Seulles--Hill 64 (west of Bazenville)--the Gronde River to Asnelles-sur-Mer. The plan for 7 June on this front was simply to muster all available troops including artillery units in *Kampfgruppen* to prevent a British break-through into Bayeux.<sup><a href="#fn93" id="cn93">93</a></sup>

*--331--*

------------------------------------------------------------------------

<span id="page332"></span>

> In the meantime the commander of the British 50th Division had decided to halt on a line north and northeast of the city roughly between Vaux-sur-Orne and Vaux-sur-Seulles. He had been advancing against very slight opposition, but because of the delays in getting started he feared that he could not occupy Bayeux and organize a proper defense before dark. He ordered the attack to be resumed at daylight.<sup><a href="#fn94" id="cn94">94</a></sup>
>
> Most of the countermeasures initiated by *OB WEST* and *Army Group B* on D Day were directed against the British. Because the British had established the most extensive beachhead, their landings seemed to constitute the main Allied effort. Matching the success of the 50th Division immediately on the flank of U.S. V Corps, the 3d Canadian Division, landing on beaches near Courseulles, had advanced from three to six miles and had sent armored patrols as far as Bretteville l'Orgueilleuse some ten miles from the beach. On its left the 3d British Division advanced beyond Biéville to within about two miles of Caen. East of the Orne River the two parachute brigades of the 6th Airborne Division had successfully accomplished their missions of seizing bridges at Bénouville and destroying the enemy coastal battery at Merville. Although the advances of all British units fell short of their objectives (particularly in the failure to take either Caen or Bayeux), they nevertheless represented the widest and deepest penetration on the Allied front. Besides, they broke through what the Germans considered an especially vital portion of the defense. Caen was the gateway to the open country constituting the best tank route to Paris. In German eyes it was therefore the key to their whole position in France.
>
> At 0500 *Army Group B* released the *21st Panzer Division* (Generalleutnant Edgar Feuchtinger) to *Seventh Army* control in order to counterattack British airborne landings east of the Orne River. For the attack the division lacked half of its infantry, one artillery battalion, and the antiaircraft and antitank battalions. These units, located on both sides of the Orne River, had been attached to the *716th Division* after the seaborne landings began. General Feuchtinger organized the remainder of his troops and started them northward. But, while still on the approach march, at about noon he was ordered to cross the Orne and make his attack west of the river to counter directly the threat to Caen. Delayed in passing through Caen where only one bridge over the Orne was still usable, Feuchtinger could not jump off until 1600. Then, with his troops organized in two regimental combat teams, he attacked the British 3d Division from about the line St. Contest-Hérouville. The attack was heavily resisted and made little progress along the Orne. But to the west one battalion struck through to Cresserons and sent elements to the coast. A few stragglers got into a Luftwaffe communications bunker near Douvres where they held out until 17 June, but the bulk of the battalion after being badly mauled pulled out. Before dark Feuchtinger halted the attack all along the line and ordered his units to dig in only a few hundred yards north of the line of departure. He tied in with

*--332--*

------------------------------------------------------------------------

<span id="page333"></span>

> infantry units of the division fighting east of the Orne.<sup><a href="#fn95" id="cn95">95</a></sup>
>
> Feuchtinger's attack, stopped before it had achieved anything, was the only large-scale counterattack on D Day. That no more decisive moves were taken was due at least in part to the muddled German command system. Rundstedt had reacted to the first news of the airborne landings with a quick decision to commit at once all operational reserves within striking distance. (<a href="maps/USA-E-XChannel-XIV.jpg" target="mapwindow"><em>Map XIV</em></a>) He took this decision, despite uncertainty as to the extent of the Allied landings, on the grounds that whether the landings were major or subsidiary it was still imperative to repel them at once. It was between 0330 and 0400, two hours before the seaborne landings, that he ordered the *12th SS Panzer Division* to move immediately toward Caen and the *Panzer Lehr Division* to prepare for similar movement.<sup><a href="#fn96" id="cn96">96</a></sup> He estimated that the reported airborne landings were on such a large scale that they could not be a mere deception maneuver and they therefore would have to be reinforced from the sea. The only feasible area for such reinforcement was the east coast of the Cotentin and the beaches between the Vire and Orne Rivers. From observation Allied assault exercises, the Germans were sure the assault on the coast would take place at dawn. Rundstedt wanted have armor at hand to counterattack the first hours. There was therefore no time to debate contingencies. He reasoned further that, even if the Normandy assault were planned by the Allies as a secondary effort, it was probable that they would exploit whatever success it achieved. The attack, whatever its character, should therefore be met with all available force. Rundstedt's reasoning was clear and his action decisive. But the two panzer divisions which he ordered to move were not under his command. They were in OKW reserve. To save precious time Rundstedt issued his orders first and then notified OKW of the action, requesting approval. OKW did not approve. At about 0730 Jodl informed Rundstedt that the two divisions would not be committed until orders were received from Hitler. The *12th SS Panzer Division* was to hold up at Lisieux; *Panzer Lehr* would not move at all. In contrast to his earlier decisiveness, Rundstedt apparently accepted this critical intervention by Hitler's staff without argument. He made no effort to reach Hitler himself.<sup><a href="#fn97" id="cn97">97</a></sup> The two panzer divisions waited, far from the beachheads, all during the morning hours of heavy overcast that might have permitted them to move without serious interference from Allied aircraft. They waited until 1600 when Hitler at last gave the word to move both divisions into battle. But by then cloud cover had broken up. Allied fighters and bombers ranged the skies smashing at everything that moved. It was necessary to delay the move further until dark.
>
> Although scattered infantry elements of the *12th SS Panzer Division* arrived

*--333--*

------------------------------------------------------------------------

<span id="page334"></span>

> during the afternoon at forward assembly areas in the zone of the *21st Panzer Division,* it was actually not until 8 June that the bulk of the two reserve divisions could be committed. The plan for their use, developed on D Day, was to place both the *12th SS* and *Panzer Lehr Divisions* under *I SS Panzer Corps* along with the *21st Panzer* and *716th Infantry Divisions* (the latter consisting at the end of the day of little more than one German battalion and about twelve artillery pieces).<sup><a href="#fn98" id="cn98">98</a></sup> The massed armor was to counterattack on the right wing of *LXXXIV Corps.* The new corps boundary was to be the former boundary between the *716th* and *352d Divisions.*
>
> The commitment of another corps in the Caen area would mean an indirect strengthening of General Marcks' (*LXXXIV Corps*) position by relieving him of responsibility for the Bayeux-Orne sector. More direct support was on the way. The *30th Mobile Brigade* was moving by bicycle from Coutances toward the invasion area, but it would not arrive until the morning of 7 June. In addition *Seventh Army* had taken the first steps to shift its weight into Normandy. In the morning the army commander, General Dollmann, ordered the *XXV Corps* in Brittany to prepare the mobile Kampfgruppen of the *275th* and *265th Infantry Divisions* for immediate movement to the invasion area. General Dollmann also wanted to move the Kampfgruppe of the *266th Division* and the entire *77th Division* from Brittany into Normandy, but Rommel considered the move premature in view of certain reports that Brittany itself might be threatened with airborne landings. When Dollmann repeated his request that night as the *352d Division* front seemed to be rapidly reaching a breaking point, Rommel yielded so far as to alert the units involved.<sup><a href="#fn99" id="cn99">99</a></sup>
>
> While waiting for these reinforcements, the *352d Division* had to depend wholly on its dwindling resources. Its last reserve, the engineer battalion, was moved from the vicinity of St. Martin-de-Blagny and attached in the evening to the *916th Regiment* in the expectation of heavy Allied attacks on 7 June to exploit the Colleville-St. Laurent beachhead.
>
> At midnight General Kraiss reported his situation to General Marcks at corps. He was not sanguine. He thought his present forces might be sufficient to hold off enemy attacks on 7 June but his losses were so heavy that he would need reinforcements for the following day's fighting. In the coastal positions, he said, he had suffered a total loss of men and equipment. His casualties for the day were about 1,200, or nearly one-fifth of his combat effectives. General Marcks replied that the reserves which could be spared to the *352d Division* had already been sent forward. Kraiss would simply have to hold on as tenaciously as possible with what he had.<sup><a href="#fn100" id="cn100">100</a></sup>
>
> Actually there was reason for the German outlook to be considerably darker than it was. All of the reinforcements ordered up on D Day would arrive late and many would take severe losses from Allied air attack on the approach march. Although all German commanders had long realized that their mobility would

*--334--*

------------------------------------------------------------------------

<span id="page335"></span>

> be severely restricted by Allied air supremacy, the full tactical significance of that fact was not yet apparent. General Dollmann, at his most pessimistic, could not have foreseen that the so-called mobile Kampfgruppen ordered out of Brittany would take ten days to reach the battle area.
>
> The immediate effect of Allied air power on the battle for the beaches was discouraging enough for the Germans. The *352d Division* observed that not a single German plane had appeared over its sector during the day. All of the 250 sorties flown by *II Air Corps* on 6 June were against shipping. The rest of the German air effort, which did not exceed 500 sorties altogether, consisted largely of fighter interventions, a good part of which occurred far inland. Some of these were planned interventions; many were chance encounters by planes sent on support missions and jumped by Allied aircraft before they could reach the battle area.<sup><a href="#fn101" id="cn101">101</a></sup> The 500 sorties of the Luftwaffe were in striking contrast to the almost 3,000 sorties by the Ninth Air Force fighters and bombers alone, flying chiefly tactical missions in the U.S. zone.<sup><a href="#fn102" id="cn102">102</a></sup>

*--335--*

------------------------------------------------------------------------

> [Table of Contents](index.html) \*\* [Previous Chapter](USA-E-XChannel-7.html) (7) \* [Next Chapter](USA-E-XChannel-9.html) (9)
>
> ------------------------------------------------------------------------
>
> ### Footnotes
>
> \[<a href="#cn1" id="fn1">1</a>\] Information on mounting and training from \[Clifford Jones\] NEPTUNE: Training, Mounting, The Artificial Ports (The Administrative and Logistical History of the ETO: Part IV), MS, pp. 275ff. Hist Div files.
>
> \[<a href="#cn2" id="fn2">2</a>\] The latter was the principal area of Eighth AF installations.
>
> \[<a href="#cn3" id="fn3">3</a>\] *Marinegruppenkommando West, KTB 16.-30.IV.44,* 27 Apr 44.
>
> \[<a href="#cn4" id="fn4">4</a>\] Jones, NEPTUNE, p. 258. Navy figures were 638 killed and 89 wounded. See *Report by Allied Naval Commander-in-Chief Expeditionary Force on Operation NEPTUNE* (London, 1944), I, 33, cited hereafter as ANCXF *Report.* Jones, historian for engineer units that were chiefly involved in the disaster, gives 749 killed, and bases his calculations on after action reports of the units and detailed casualty breakdowns. Even so, he feels his figures may be incomplete.
>
> \[<a href="#cn5" id="fn5">5</a>\] Diary of CinC, 28 Apr 44.
>
> \[<a href="#cn6" id="fn6">6</a>\] *Maringruppenkommando West, KTB 16.-30.IV.44,* 8 Apr 44. On the basis of a German broadcast, the ANCXF *Report* erroneously stated that the Germans were unaware of the nature of their success. ANCXF *Report,* I, 33.
>
> \[<a href="#cn7" id="fn7">7</a>\] ANCXF *Report,* Vol. III, Rpt, Comdr Assault Force 0, p. 5; *Ibid.,* Rpt, Comdr Assault Force U, pp. 13-14.
>
> \[<a href="#cn8" id="fn8">8</a>\] Cbl. Eisenhower Personal Files.
>
> \[<a href="#cn9" id="fn9">9</a>\] The first ships actually sailed on 31 May. They were 54 "Corncobs" (Blockships) for the artificial harbors which weighed anchor from Oban.
>
> \[<a href="#cn10" id="fn10">10</a>\] Account of the meeting from notes made by Air Vice Marshal James M. Robb, SHAEF CofS for Air Direct quotes are as given by Robb in sgd rpt, Mon A.M., 5 Jun 44. Hist Div files.
>
> \[<a href="#cn11" id="fn11">11</a>\] *Seekriegsleitung/1.Abt., KTB 1.-30.VI.44,* 3 Jun 44.
>
> \[<a href="#cn12" id="fn12">12</a>\] *Fifteenth Army,* *KTB 1.I.-30.VI.44,* 5 Jun 44.
>
> \[<a href="#cn13" id="fn13">13</a>\] Double British Summer Time. German clocks, set by Central European time, showed 2115. All times given in text are DBST.
>
> \[<a href="#cn14" id="fn14">14</a>\] Rad, 5 Jun 44, *Seventh Army* to *XXV, LXXIV,* and *LXXXIV Corps.* *Seventh Army,* *KTB Anlagen 1.V.-5.VI.44.*
>
> \[<a href="#cn15" id="fn15">15</a>\] *Marinegruppenkommando West, KTB 1.-7.VI.44,* 6 Jun 44.
>
> \[<a href="#cn16" id="fn16">16</a>\] Wave heights between five and eight feet.
>
> \[<a href="#cn17" id="fn17">17</a>\] *Seventh* and *Fifteenth Army* commanders thought the weather was not too adverse for invasion, but it is not clear what standards they applied. See the *KTB/'s* for the respective armies. The almost complete lack of coordination between Army, Navy, and Air Force headquarters makes generalization on German preparedness extremely difficult.
>
> \[<a href="#cn18" id="fn18">18</a>\] One German meteorologist commented that commanders were virtually reduced to looking at the morning skies for their weather forecasts. See Interv with Maj Heinz Lettau, 5 Oct 49. Hist Div files.
>
> \[<a href="#cn19" id="fn19">19</a>\] It is likely, however, that they would not have considered that the break made invasion possible, since weather conditions were still unsettled and the German Navy view was that at least five consecutive days of favorable weather would be necessary for the success of the landings. Rpt, *Beitraege zur Frage der Landemocglichheiten an der Kueste des Kanals,* 1 Jan 44. *Seekriegsleitung/1.Abt., KTB Anlagen 1.I.-30.VI.44.*
>
> \[<a href="#cn20" id="fn20">20</a>\] The story told by Captain Harry C. Butcher, *My Three Years with Eisenhower* (New York, 1946), pp. 646-47, concerning German weather predictions is erroneous. Major Lettau, far from being "the chief German meteorologist," was in fact attached to an antiaircraft outfit and had nothing to do with forecasting invasion weather. He was with the *155th Flak Regiment,* stationed in Amiens, and his job was to analyze flying conditions over England from data collected by radio sound stations. See interv cited [n. 18](#fn18).
>
> \[<a href="#cn21" id="fn21">21</a>\] *Marinegruppenkommando West, KTB 1.-7.VI.44,* 6 Jun 44,
>
> \[<a href="#cn22" id="fn22">22</a>\] Hoffmann Report. *Seventh Army,* *KTB Anlagen 1.I.-30.VI.44.*
>
> \[<a href="#cn23" id="fn23">23</a>\] Naval district commander for the Normandy coast, under *Admiral Kanalhueste* who had the whole Channel coast command. See <a href="charts/USA-E-XChannel-4.jpg" target="mapwindow">naval command chart</a>, p. 245.
>
> \[<a href="#cn24" id="fn24">24</a>\] He reversed himself later in the day to agree with higher command estimates. Tel Msgs. *Seventh Army,* *KTB Anlagen 1.I.-30.VI.44.*
>
> \[<a href="#cn25" id="fn25">25</a>\] See First Army G-3 Jnl.
>
> \[<a href="#cn26" id="fn26">26</a>\] Allied airborne operations required 1,087 transport aircraft including lift for the pathfinders but excluding aircraft used to tow gliders. See AEAF Memo, Operation "NEPTUNE," Employment of British and American Airborne Forces, 27 May 44. SHAEF G-3 file 24533/Ops Future Operations). Pathfinders of the 101st Airborne Division began dropping at 0015; the first serial of combat troops was scheduled to drop at 0119. See Leonard Rapport and Arthur Norwood, Jr., *Rendezvous with Destiny* (Washington, 1948), pp. 73, 94.
>
> Records of airborne operations in the Cotentin are very sketchy; those of the 101st Airborne Division in particular are all but useless. The narrative following is based on a set of comprehensive interviews conducted dunng July 1944 by Col. S. L. A. Marshall with officers and men of the airborne units. Colonel Marshall, subsequently European Theater Historian, developed the information thus secured in a number of battalion and regimental studies which in mimeographed form are in the Historical Division files. The airborne material is exploited in greater detail than here in \[R. G. Ruppenthal\] *<a href="../USA-A-Utah/index.html" target="mapwindow">Utah Beach to Cherbourg</a>* (Washington, 1948), to which the author is generally indebted for the bulk of the story of U.S. VII Corps operations during June 1944. See <a href="USA-E-XChannel-Biblio.html" target="mapwindow">Bibliographical Note.</a>
>
> \[<a href="#cn27" id="fn27">27</a>\] 377th FA Bn AAR.
>
> \[<a href="#cn28" id="fn28">28</a>\] Bombing had not injured the six Russian 122-mm. guns at the St. Martin emplacement but had so damaged the fire control setup that the guns were moved before the invasion. See MS \# B-260 (Generalmajor Gerhard Triepel, gen. Schulze). Triepel during the first half of June commanded the *1261st Army Coastal Artillery Regiment;* in the latter half, he was artillery commander of *LXXXIV Corps.*
>
> \[<a href="#cn29" id="fn29">29</a>\] Summers was awarded the DSC. Details of the action from interviews by Col. S. L. A. Marsball. Hist Div files.
>
> \[<a href="#cn30" id="fn30">30</a>\] General Taylor, commissioned in the Corps of Engineers from West Point in 1922, transferred to the Field Artillery in 1926. As chief of staff of the 82d Division in 1942 he assisted in organizing the first airborne divisions. In 1943 he went overseas as artillery commander of the reorganized 82d Airborne Division. After serving through the Sicilian and Italian campaigns he received command of the 101st Airborne Division in March 1944.
>
> \[<a href="#cn31" id="fn31">31</a>\] Probably of the *3d Battalion,* whose headquarters was at St. Côme-du-Mont.
>
> \[<a href="#cn32" id="fn32">32</a>\] MS \# D-330 (Blumentritt).
>
> \[<a href="#cn33" id="fn33">33</a>\] Another of the batteries was captured still later by the 8th Infantry. See below, <a href="#page329" target="mapwindow">p. 329</a>.
>
> \[<a href="#cn34" id="fn34">34</a>\] Total D-Day casualties calculated in August 1944 amounted to 1240 including 182 known killed and 501 missing and presumed captured or killed. See 32d MRU Rpt, Analysis of Battle Casualty Reports. Received from 101st Airborne Division. 13 Aug 44. FUSA file CC 21. dr 4, item 704.
>
> \[<a href="#cn35" id="fn35">35</a>\] See below, [pp. 293](#page293) ff.
>
> \[<a href="#cn36" id="fn36">36</a>\] The account here follows that of Col. S. L. A. Marshall, who interviewed a number of the officers and men, including Colonel Johnson, soon after the action. See Marshall's account in The Fight at the Lock, mimeo MS. Hist Div files. Some doubt has subsequently arisen as to whether Johnson reached the lock during the morning *before* he made contact with Major Allen. See Lawrence Critchell, *Four Stars of Hell* (New York, 147), pp. 524. In view of Colonel Johnson' death, the issue cannot be finally settled. The evidence for Critchell's version does not seem conclusive. See Leonard Rapport and Arthur Norwood, Jr., *Rendezvous with Destiny* (Washington, 1948), p. 111. Rapport tried unsuccesfully to resolve the difliculty through extenive correpondence with survivors.
>
> \[<a href="#cn37" id="fn37">37</a>\] See above, [n. 34](#fn34).
>
> \[<a href="#cn38" id="fn38">38</a>\] General Ridgway, a 1917 graduate of the U.S. Military Academy, served with the War Plans Division of the War Department from 1939 to 1942. He then became assistant division commander of the 82d Division at its activation in March 1942 and commander three months later. When that division was reorganied as the 82d Airborne Division he continued to command and led it in the Sicilian and Italian campaigns.
>
> \[<a href="#cn39" id="fn39">39</a>\] For extraordinary heroism in the capture and defense of Ste. Mère-Eglise Colonels Krause and Vandervoort were awarded the DSC.
>
> \[<a href="#cn40" id="fn40">40</a>\] General Gavin, a graduate of West Point in 1929, took command of the 505th Parachute Infantry in July 1942 and led that regiment into combat in Sicily a year later. He commanded the same regiment in the parachute landing on Salerno Bay in September 1943 and the following month became assistant division commander.
>
> \[<a href="#cn41" id="fn41">41</a>\] By the original plan Ridgway was supposed to come in by glider just before dawn, but this was changed a few days before D Day. See Ltr, Ridgway to Maj Gen Harry J. Malony, 12 Nov 48. Hist Div files.
>
> \[<a href="#cn42" id="fn42">42</a>\] See S. L. A. Marshall, La Fière Bridgehead, mimeo MS. Hist Div file. The acount in Ruppenthal, Utah Beach, [p. 38](../USA-A-Utah/USA-A-Utah-2.html#page38), differs slightly.
>
> \[<a href="#cn43" id="fn43">43</a>\] Undoubtedly units of the *100th Panzer Replacement Battalion* equipped with light Russian and French tanks.
>
> \[<a href="#cn44" id="fn44">44</a>\] Their tenacity may in part have been caused by the shooting on two occasions of enemy soldiers who stood up apparently with the idea of surrendering. See Marshall, La Fière Bridgehead.
>
> \[<a href="#cn45" id="fn45">45</a>\] All three were captured. Pvt Zwingman was kilied in December 1944 while still a prisoner. The three men were awarded DSC's.
>
> \[<a href="#cn46" id="fn46">46</a>\] *Seventh Army KTB 1.I.-30.VI.44,* 6 Jun 44. Schlieben denies that the *1058th Regiment* was attached to his division and in fact the regiment's action on D Day does not seem to have been directed at first by the *709th Division.* MS \# B-845 (Schlieben).
>
> \[<a href="#cn47" id="fn47">47</a>\] Again the subordination ordered by *Seventh Army* was apparently not effected. Von der Heydte directed the operations of his regiment without any orders from the *91st Division.* MS \# B-839 (von der Heydte) .
>
> \[<a href="#cn48" id="fn48">48</a>\] The regiment, nominally the *922d,* contained a battalion of the *922d,* a battalion of the *920th,* and the division's *Engineer Battalion.* MS \# B-845 (Schlieben) .
>
> \[<a href="#cn49" id="fn49">49</a>\] MS \# B-845 (Schlieben); MS \# 260 (Triepel) .
>
> \[<a href="#cn50" id="fn50">50</a>\] MS \# B-845 (Schlieben).
>
> \[<a href="#cn51" id="fn51">51</a>\] This paragraph and the following two are from von der Heydte's report, MS \# B-839. The Wannsee is a lake near Berlin, a favorite place for Berliners to spend a Sunday.
>
> \[<a href="#cn52" id="fn52">52</a>\] See below, <a href="USA-E-XChannel-9.html" target="mapwindow">Ch. IX</a>.
>
> \[<a href="#cn53" id="fn53">53</a>\] 82d Div AAR. At noon, 8 June, the division reported still only 2,100 effectives--or less than a third of its combat strength.
>
> \[<a href="#cn54" id="fn54">54</a>\] See Phantom Intercept in 21 A Gp Sitrep 4. SHAEF G-1 file 704/6, 21 A Gp Casualty Rpts, Vol. I.
>
> \[<a href="#cn55" id="fn55">55</a>\] 32d MRU Rpt, Analysis of Battle Casualty Reports received from 82d Airborne Division, 1 Aug 44. FUSA file CC 21, dr 4, item 704.
>
> \[<a href="#cn56" id="fn56">56</a>\] ANCXF *Report,* Vol. III, Annex D, p. 44.
>
> \[<a href="#cn57" id="fn57">57</a>\] Prov Eng Spec Brig AAR.
>
> \[<a href="#cn58" id="fn58">58</a>\] *Marinegruppenkommando West, KTB 1.-7.VI.44,* 6 Jun 4.
>
> \[<a href="#cn59" id="fn59">59</a>\] Notes by Col B. B. Talley, Asst CofS, V Corps. Hist Div files. Talley also says the rocket-carrying LST's did not come up on line and consequently did not fire their rockets simultaneously as planned.
>
> \[<a href="#cn60" id="fn60">60</a>\] General Barton had been chief of staff at headquarters of the 4th Division in 1940. In June 1942 he took command of the 4th Motorized Division, which subsequently became the 4th Infantry Division, and in January of 1944 arrived with his unit in the European theater.
>
> \[<a href="#cn61" id="fn61">61</a>\] 4th Div FO 1, 12 May 44.
>
> \[<a href="#cn62" id="fn62">62</a>\] 4th Cav Gp AAR.
>
> \[<a href="#cn63" id="fn63">63</a>\] Brig. Gen. Theodore Roosevelt, assistant division commander, who went ashore with the first wave and helped organize the attack inland, was awarded the [Medal of Honor](../../MoH_P-T.html#roosevelt) for gallantry displayed in his leadership under fire.
>
> \[<a href="#cn64" id="fn64">64</a>\] First Army G-3 Jnl.
>
> \[<a href="#cn65" id="fn65">65</a>\] Maj. Gen. Leonard T. Gerow was graduated frorm the Virginia Military Institute in 1911. Between 1920 and 1940 he was on four separate occasions assigned to War Department staff duty: in the War Plans and Organization Section (1923-24), in the office of the Assistant Secretary of War (1926-29), in the War Plans Division (1935-39), and as Assistant Chief of Staff with duty in the War Plans Division (1940-41). he commanded the 29th Division in 1942 and took command of V Corps in July 1943.
>
> General Huebner enlisted in 1910 was commissioned in the infantry in 1916. He went overseas as commander of a company of the 28th Infantry in 1917 and served with the 1st Division at Lunéville, Beaumont, Cantigny, and in the Aisne-Marne, St. Mihiel and Muese-Argonne offensives. He was twice wounded and received the DSC with cluster, the DSM, and Silver Star. In 1940 he was chief of the Training Branch of the Operations and Training Division of the War Department and in 1942 Director of the Training Division, Headquarters SOS. In August 1943 he took command of the 1st Division in North Africa.
>
> \[<a href="#cn66" id="fn66">66</a>\] See above, <a href="USA-E-XChannel-5.html#page187" target="mapwindow">p. 187</a>.
>
> \[<a href="#cn67" id="fn67">67</a>\] The road that passes through les Moulins will be called herafter the les Moulins Exit. The St. Laurent Exit will refer to the road immediately east which leads up the valley of the Ruguet River. Note that the towns of Vierville, St. Laurent, and Colleville in this sector all bear the suffixes "sur-Mer." Only in the case of Vierville will the suffix be retained in order not to confuse it with the other Vierville in the UTAH Beach sector.
>
> \[<a href="#cn68" id="fn68">68</a>\] German coastal defense works were of four classes depending on size and complexity. The smallest and most usual was the resistance nest (*Widerstandsnest*), a single self-contained defensive position manned by one or two squads sometimes though not necessarily with heavy weapons. When several resistance nests were combined for coodrdinated defense of a larger sector the defense was called a strong point (*Steutzpunkt*). Strong points in general were manned by at least a platoon of infantry with heavy weapons and a local reserve. Strong points might be grouped in a *Stuetzpunktgruppe* either for command unity or for defense of a small fortified area. None of these strong point groups existed in the invasion area. Finally, certain strategically important places like ports, submarine pens, and mouths of large rivers were organized into defensive areas (*Verteidigungbereiche*) garrisoned by bits whose size was conditioned by the size and importance of the area and the forces available. All had both local reserves wiithin the defensive area and reserves in general support stationed outside. See *Grundlegender Befehl des Oberbefehlshabers West Nr. y, Begriffsbestimmungen in der Kuestenverteidigung,* 28 May 42. *OWK/WFst, Op. (H.), Grundlegende Befehle West 28.IV.42-7.V.44.*
>
> \[<a href="#cn69" id="fn69">69</a>\] Three of the five were beached by an LCT which could not lower its ramp at sea. For details of the difficulties in the initial landings at OMAHA see \[Charles H. Taylor\] *<a href="../USA-A-Omaha/index.html" target="mapwindow">Omaha Beachhead</a>* (Washington, 1945). The narrative of U.S. V Corps operations is largely based on Taylor's study. See <a href="USA-E-XChannel-Biblio.html" target="mapwindow">Bibliographical Note</a>.
>
> \[<a href="#cn70" id="fn70">70</a>\] Ltr, *OB WEST, O.Qu.* to *OKH/Generalquartiermeister,* 4 Feb 44. *OKH/Generalquartiermeister, Stuetzpunktbevorratung an der Atlantik- und Kanalkueste.*
>
> \[<a href="#cn71" id="fn71">71</a>\] About 80 yards of sand would be covered each hour.
>
> \[<a href="#cn72" id="fn72">72</a>\] For a complete list of the DSC winners, see <a href="USA-E-XChannel-I.html" target="mapwindow">App. I</a>, below.
>
> \[<a href="#cn73" id="fn73">73</a>\] 73 Major Bingham was awarded the DSC.
>
> \[<a href="#cn74" id="fn74">74</a>\] Carrying heavy communications equipment through the surf under enemy fire was a formidable task that took many lives. Five men of the 16th Infantry were decorated for their heroic work in struggling ashore with vital radios and wire despite serious wounds. T/5 John J. Pinder, Jr., received a posthumous award of the <a href="../../MoH_P-T.html#pinder" target="mapwindow">Medal of Honor</a> for his intrepidity in recovering two radios and other equipment, while suffering two severe wounds. On his third trip into the fire-swept surf he was killed.
>
> \[<a href="#cn75" id="fn75">75</a>\] Reasons for this failure remain one of the more interesting mysteries of the war. Allied intelligence had otherwise a remarkably detailed and accurate picture of the German defenses and troop dispositions. It was unquestionably difficult to get reliable information from agents in the coastal zone since all persons whom the Germans allowed to remain in these areas were carefully screened. In this connection the short distance of the move of the *352d Division* from St. Lô to the coast may have contributed to concealing it, although a similar inching forward of the *21st Panzer Division* was found out. Another interesting surmise is suggested by the fact that one agent known to be active in the zone of the *352d Division* as late as May was working in the Grandcamp area which happened to be the sector of the *3d Battalion* of the *726th Regiment* of the *716th Division.* That the *726th Regiment* had been attached to a new division could easily have been unknown to him. In May the Germans shot down a carrier pigeon carrying a message from this agent. The message was a report of the location of the *3d Battalion* of the *1716th Artillery Regiment,* also in the Grandcamp area and also a *716th Division* unit, attached to the *352d.* See MS \# B-022 (Ziegelmann). Brigadier Williams, G-2 of 21 A Gp, has said since the war that just before the invasion he did find out about the *352d's* presence on the coast but was unable to inform the troops. See Interv, Pogue with Williams, London, 31 May 47. This is partially confirmed by 21 Army Group Weekly Neptune Review 17 of 4 June which warned: "It should not be surprising if we discovered that it (the *716th Division*) had two regiments in the line and one in reserve while on its left *352d Division* had one regiment up and two to play...." The fact remains noteworthy that for almost two and a half months the Allies were unaware of the true position of the *352d Division.*
>
> \[<a href="#cn76" id="fn76">76</a>\] MS \# B-432 (Ziegelmann).
>
> \[<a href="#cn77" id="fn77">77</a>\] Talley Notes, cited [n. 59](#fn59). The milling of the landing craft offshore was actually caused at least as much hy an order from the 7th Naval Beach Battalion at about 0830 to suspend the landing of vehicles pending clearance of some beach exits. This fact seems to have been unknown to Talley. see below, next section. Cf. Taylor, *Omaha Beachhead,* <a href="../USA-A-Omaha/USA-A-Omaha-4.html#page79" target="mapwindow">p. 79</a>. Talley was awarded the DSC for his liaison work on 6 June.
>
> \[<a href="#cn78" id="fn78">78</a>\] Facts on British action furnished by the British Cabinet Office Hist Sec.
>
> \[<a href="#cn79" id="fn79">79</a>\] MS \# B-432 (Ziegelmann).
>
> \[<a href="#cn80" id="fn80">80</a>\] Admiral Hall, commander of Task Force O, paid special tribute to U.S. destroyers *Carmick,* *Doyle,* *McCook,* *Thompson,* *Frankford,* *Harding,* *Emmons,* and *Baldwin,* and British Hunt class destroyers *Melbreak,* *Talybont,* and *Tanatside.* ANCXF *Report,* Vol. III, Rpt, Comdr Assault Force O, p. 56.
>
> \[<a href="#cn81" id="fn81">81</a>\] Colonel Rudder was awarded the DSC for extraordinary heroism in continuing to lead his battalion despite being twice wounded.
>
> \[<a href="#cn82" id="fn82">82</a>\] The *352d Division,* anticipating commando assaults on the cliffs, had laid 240-mm. shells hooked to trip wires, along the crest at 100-yard intervals. They were designed to roll down and explode over the water with an effective radius of about 650 yards. These shells caused no diflculty for the Rangers although they hindered beach clearance parties later on. See Talley Notes, cited n. 59; MS \# B-432 (Ziegelmann).
>
> \[<a href="#cn83" id="fn83">83</a>\] For a detailed account of the Ranger action, see Charles H. Taylor, "Pointe du Hoe," *<a href="../USA-A-Small/index.html" target="mapwindow">Small Unit Actions</a>* (Washington, 1946).
>
> \[<a href="#cn84" id="fn84">84</a>\] Both General Cota and Colonel Canham were awarded the DSC for extraordinary heroism shown during their D-Day leadership under fire.
>
> \[<a href="#cn85" id="fn85">85</a>\] American losses were one killed and five wounded. Thirty-one German prisoners were taken at the strong.point. See Combat Interv, 16th Inf.
>
> \[<a href="#cn86" id="fn86">86</a>\] \*Not\* the 149th, as given in Taylor, *Omaha Beachhead,* <a href="../USA-A-Omaha/USA-A-Omaha-4.html#page82" target="mapwindow">p. 82</a>.
>
> \[<a href="#cn87" id="fn87">87</a>\] Notes on V Corps Plan, 17 May 44. Pre-Inv file 670. Compare this use of a floating reserve with that proposed by British Commanders following the Dieppe raid. See above, <a href="USA-E-XChannel-5.html#page191" target="mapwindow">p. 191</a>.
>
> \[<a href="#cn88" id="fn88">88</a>\] Ltr. Gerhardt to Gen Malony, 2 Jan 47. Hist Div files. General Gerhardt was commissioned in the cavalry from West Point in 1917. He served with the 89th Division in the St. Mihiel and Meuse-Argonne offensives in 1918. In May 1942 he became commander of the 91st Division and in July took command of the 29th Division in England.
>
> \[<a href="#cn89" id="fn89">89</a>\] 18th Inf S-1 Jnl, 6 Jun 44.
>
> \[<a href="#cn90" id="fn90">90</a>\] This is frankly a guess, based on a number of estimates of various dates and various headquarters none of which agree. Under the Army's present casualty reporting system, it is unlikely that accurate figures of D-Day losses by unit will ever be available. The *V Corps History* gives D-Day losses as 2,374, of which the 1st Division lost 1,190, the 29th Division 743, and corps troops 441. The after action report of the 1st Division and the 29th Division history both scale down their own losses slightly. See Joseph H. Ewing, 29, *Let's Go* (Washington, 1948), p. 306. Source for the 1st Division report is its own G-1 report of daily casualties; source for the 29th Division figures is not given. On 8 June the 1st Division G-1 issued a "corrected" casualty report for D Day and D plus 1 which reduced total losses reported for the two days from 1,870 to 1,036. See V Corps G-3 Jnl. Neither the original report nor the corrected one conforms to the division G-1's accounting in his monthly report of operations. See study of First Army casualties during June 1944, prepared by Royce L. Thompson, MS. Hist Div files.
>
> \[<a href="#cn91" id="fn91">91</a>\] It is possible that the Germans were interpreting as concentration of force what was actually only congestion of landing craft backlogged by the difficulties of beaching them. See above, [n. 77](#fn77).
>
> \[<a href="#cn92" id="fn92">92</a>\] Consisting of the *1st Battalion,* *915th Regiment,* the *352d Fuesilier Battalion,* and one company of the *352d Antitank Battalion* (the *1352d Assault Gun Company*) equipped with ten assault guns. MS \# B-432. Ziegelmann's reference to the *1352d Assault Gun Battalion* is an error. Cf. *Kriegsgliederung,* 18 May 44. *Seventh Army, KTB Anlagen 1.I.-30.VI.44.*
>
> \[<a href="#cn93" id="fn93">93</a>\] This story has been pieced together from the telephone diary of the *352d Division* and from reports of British action supplied to the author by the British Cabinet Office Hist Sec. The account (MS \# B-432) written after the war by Lt. Col. Ziegelmann, G-3 of the *352d Division,* telling of a counterattack smashed by Allied fighter bomber interception and overrun by British tanks seems considerably exaggerated .
>
> \[<a href="#cn94" id="fn94">94</a>\] From information furnished by British Cabinet Office Hist Sec.
>
> \[<a href="#cn95" id="fn95">95</a>\] MS \# B-441 (Feuchtinger) .
>
> \[<a href="#cn96" id="fn96">96</a>\] This timing is given in MS \# T-121 (Zimmermann et al.). See also Rad, 0445 (0545 DBST), *OB WEST* to *OKW/WFSt,* 6 Jun 44. *OKH/Op.Abt., Lagemeldungen OB WEST l.IV.-8.VI.44;* cf. *Fifteenth Army, KTB 1.I.-30.VI.44,* 6 Jun 44. Rundstedt's reasoning detailed in the remainder of the paragraph is as reported in MS \# T-121.
>
> \[<a href="#cn97" id="fn97">97</a>\] Under the German command system it would have been perfectly proper for Rundstedt to have appealed directly to Hitler, since OKW itself did not have command authority except as it spoke in Hitler's name.
>
> \[<a href="#cn98" id="fn98">98</a>\] MS \# B-621 (Richter).
>
> \[<a href="#cn99" id="fn99">99</a>\] *Seventh Army, KTB 1.I.-30.VI.44,* 6 Jun 44.
>
> \[<a href="#cn100" id="fn100">100</a>\] MS \# B-432 (Ziegelmann).
>
> \[<a href="#cn101" id="fn101">101</a>\] MS \# B-620 (Buelowius).
>
> \[<a href="#cn102" id="fn102">102</a>\] \[Lt Col Robert H. George\] Ninth Air Force, April to November 1944 (Army Air Forces Historical Studies: No. 36), MS, p. 81. AAF files.

------------------------------------------------------------------------

------------------------------------------------------------------------

Transcribed and formatted for HTML by Patrick Clancey, HyperWar Foundation
